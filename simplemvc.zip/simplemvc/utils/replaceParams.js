export default class replaceParams
{

    // Rep un array de parametres [{id:...,name:...,text:...}]
    // Amb el nom del paràmetre i el text pel qual l'ha de substituir
    // Substitueix els paràmetres amb el text
    static replace(params,html)
    {
        params.map((param)=> {
            let paramReplace = "{{" + param.name.toUpperCase() +"}}";
            html=html.replace(paramReplace, param.text);
        });
    
        return html;
    }
}