import CategoriesController from "./CategoriesController.js";
import ProductesController from "./ProductesController.js";
import HomeController from "./HomeController.js";

export default class MainController {

  constructor() {
    // Cream tots els controladors
    this.myHomeController = new HomeController();
    this.myCategories = new CategoriesController();
    this.myProductes = new ProductesController();
  }

  doAction(action, id) {
    switch (action) {

      case "home":
        this.myHomeController.doAction("getHome");
        break;

      case "categories":
        this.myCategories.doAction("getAll");
        break;

      case "productes":
        this.myProductes.doAction("getAll");
        break;

      case "buscarProductes":
        this.myProductes.doAction("getByName");
        break;

      case "buscarProductesId":
        this.myProductes.doAction("getById");
        break;

      case "crearProducte":
        this.myProductes.doAction("crearProducte");
        break;

      case "insertProducte":
        this.myProductes.doAction("insertProducte");
        break;

      case "editarProducte":
        this.myProductes.doAction("editarProducte", id);
        break;
      case "buscarProductesCategoria":
        this.myProductes.doAction("getByCategoryName");
        break;
      case "buscarProductesPrecio":
        this.myProductes.doAction("getByPriceRange");
         break;
      case "updateProducte":
        this.myProductes.doAction("updateProducte");
        break;
      case "deleteProducte":
        console.log("Eliminando producto" + id);

        this.myProductes.doAction("deleteProducte", id);
        
        console.log("Eliminando producto");
        break;
      case "buscarCategorias":
        this.myCategories.doAction("getByName");
      break;
      case "buscarCategoriasID":
        this.myCategories.doAction("getById");
        break;
      case "crearCategoria":
        this.myCategories.doAction("crearCategoria");
        break;
      case "insertarCategoria":
        this.myCategories.doAction("insertarCategoria");
        break;
      case "editarCategoria":
        this.myCategories.doAction("editarCategoria",id);
        break;
      case "deleteCategoria":
        this.myCategories.doAction("deleteCategoria",id);
        break;
      case "updateCategoria":
        this.myCategories.doAction("updateCategoria");
        break;
      default:
        console.warn("MainController: acción no reconocida:", action);
        break;
    }
  }
}
