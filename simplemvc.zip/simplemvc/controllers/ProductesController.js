import ProductesView from "../views/ProductesView.js";
import ProductesModel from "../model/ProductesModel.js";
import ProducteView from "../views/ProducteView.js";

export default class ProductesController {
  constructor() {
    this.model = new ProductesModel();      // crea el modelo
    this.viewProducte = new ProducteView(); // vista de producto (create/edit)
    this.viewProductes = new ProductesView(); // vista de listado
  }

  async doAction(action, id) {
    switch (action) {

      case "getAll": {
        const productes = await this.model.getAll();
        console.log(productes)
        this.viewProductes.render(productes);
        break;
      }

      case "getById":{
        console.log("getById")

        const idSearch =  this.viewProductes.getidSearch();

        console.log(idSearch);

        const producte = await this.model.getById(idSearch);

        console.log(producte);

        this.viewProductes.render(producte);

        break;
      }
      case "getByName": {
        console.log("getByName")
        
        const nameSearch =  this.viewProductes.getTextSearch();

        console.log(nameSearch)

        const productes = await this.model.getByName(nameSearch);

        console.log(productes)

        this.viewProductes.render(productes);
        break;
      }

      case "crearProducte":
        await this.viewProducte.renderCreate();
        break;

      case "insertProducte":
        await this.model.insertProducte(this.viewProducte.getProducte());
        this.doAction("getAll");
        break;

      case "editarProducte": {
        const producte = await this.model.getByID(id);
        this.viewProducte.renderEdit(producte);
        break;
      }

     case "updateProducte": {
    const producte = this.viewProducte.getProducte(); // objeto simple
    const actualizado = await this.model.updateProducte(producte);

    if (actualizado) {
        alert("Producto actualizado correctamente!");
        // Refresca la lista
         this.doAction("getAll")
    } else {
        alert("Error al actualizar el producto.");
    }
    break;
}

    }
  }
}
