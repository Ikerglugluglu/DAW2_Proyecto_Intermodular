import ProductesView from "../views/ProductesView.js";
import ProductesModel from "../model/ProductesModel.js";
import ProducteView from "../views/ProducteView.js";
import CategoriesModel  from "../model/CategoriesModel.js";
export default class ProductesController {
  constructor() {
    this.model = new ProductesModel();      // crea el modelo
    this.viewProducte = new ProducteView(); // vista de producto (create/edit)
    this.viewProductes = new ProductesView(); // vista de listado
    this.categoriesModel = new CategoriesModel(); // Modelo de categorias
  }

  async loadCategories(){
    this.categories = await this.categoriesModel.getAll();
  }

  async doAction(action, id) {
    switch (action) {

      case "getAll": {
        const productes = await this.model.getAll();
        const categories = await this.categoriesModel.getAll()
        console.log(productes)
        this.viewProductes.render(productes);
        this.viewProductes.renderCategoryFilter(categories);
        break;
      }
      case "getById":{
        console.log("getById")

        const idSearch =  this.viewProductes.getidSearch();

        console.log(idSearch);

        const producte = await this.model.getById(idSearch);

        console.log(producte);

        this.viewProductes.render(producte);

        break;
      }
      case "getByName": {
        console.log("getByName")
        
        const nameSearch =  this.viewProductes.getTextSearch();

        console.log(nameSearch)

        const productes = await this.model.getByName(nameSearch);

        console.log(productes)

        this.viewProductes.render(productes);
        break;
      }

      case "crearProducte":
        await this.loadCategories();
        await this.viewProducte.renderCreate(this.categories);
        break;

      case "insertProducte":
        await this.model.insertProducte(this.viewProducte.getProducte());
        this.doAction("getAll");
        break;

      case "editarProducte": {
        const producte = await this.model.getById(id);
        console.log(producte)
        await this.loadCategories();
        this.viewProducte.renderEdit(producte, this.categories);
        break;
      }
     case "deleteProducte":{
        
        const confirmado = confirm("¿Seguro que quieres eliminar este producto?");
        if (!confirmado) break;
      
        console.log("Eliminamos " + id);
        const producte = await this.model.getById(id);
        console.log(producte);
        const eliminar = await this.model.deleteProducte(producte);
        if (eliminar) {
        alert("Producto eliminado correctamente!");
        // Refresca la lista
         this.doAction("getAll")
        } else {
        alert("Error al eliminar el producto.");
    }
        break;

     }
     case "getByCategoryName": {
    console.log("getByCategoryName");

    // Obtenemos el nombre de la categoría desde la vista (puede ser un input específico)
    const categoryName = this.viewProductes.getCategorySearch(); // Asegúrate de crear este método en ProductesView

    console.log("Buscando productos en la categoría:", categoryName);

    // Llamamos al modelo
    const productes = await this.model.getByCategoryName(categoryName);

    console.log(productes);
    await this.loadCategories(); // cargamos categorías para traducir id → nombre
    // Renderizamos la lista filtrada
    this.viewProductes.render(productes, this.categories);
    break;
}

     case "updateProducte": {
    const producte = this.viewProducte.getProducte();
      
    if(isNaN(producte.precio)){
      this.viewProducte.showError("precio error")
    } else{}
    
    const actualizado = await this.model.updateProducte(producte);

    if (actualizado) {
        alert("Producto actualizado correctamente!");
        // Refresca la lista
         this.doAction("getAll")
    } else {
        alert("Error al actualizar el producto.");
    }
    break;
}

case "getByPriceRange": {
    console.log("getByPriceRange");

    // Obtenemos los valores desde la vista
    const minPrice = this.viewProductes.getMinPrice();
    const maxPrice = this.viewProductes.getMaxPrice();

    console.log("Rango de precios:", minPrice, maxPrice);

    // Validación básica
    if (isNaN(minPrice) || isNaN(maxPrice)) {
        alert("El rango de precios no es válido");
        break;
    }

    // Llamamos al modelo
    const productes = await this.model.getByPriceRange(minPrice, maxPrice);

    console.log(productes);

    // Renderizamos
    this.viewProductes.render(productes);
    break;
}


    }
  }
}
