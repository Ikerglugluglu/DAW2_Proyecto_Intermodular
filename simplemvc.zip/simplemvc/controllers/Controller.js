class Controller {
    constructor() {
        this.model = new Model;		// crea el modelo
        this.view = new View;		// crea la vista
    }
  
    init() {
        this.view.init();			// inicializa la vista, si es necesario
    }


    doAction(action)
    {
        switch(action) {
            case "":
              // code block
              break;
            case "":
              // code block
              break;
            default:
              // code block
          }


    }

}
