import HomeView from "../views/HomeView.js";
import HomeModel from "../model/HomeModel.js";

export default class HomeController {
  constructor() {
    this.model = new HomeModel();   // crea el modelo
    this.view = new HomeView();     // crea la vista
  }

  doAction(action) {
    switch (action) {
      case "getHome":
        // OJO!!: Aquí podríem necessitar async
        const homeText = this.model.getHomeText();
        this.view.render(homeText);
        break;
      default:
        console.error("HomeController: acción no reconocida:", action);
        break;
    }
  }
}
