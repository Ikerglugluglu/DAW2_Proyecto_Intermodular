import CategoriesView from "../views/CategoriesView.js";
import CategoriesModel from "../model/CategoriesModel.js";

export default class CategoriesController {
    constructor() {
        this.model = new CategoriesModel();
        this.viewCategories = new CategoriesView();
    }

    doAction(action) {
        switch(action) {
            case "getAll":
                const categories = this.model.getAll(); 
                this.viewCategories.render(categories);
                break;

            // Afegir altres casos
            // insertCategoria, editarCategoria, updateCategoria, deleteCategoria

            default:
                console.error("CategoriesController: acción no reconocida:", action);
                break;
        }
    }
}
