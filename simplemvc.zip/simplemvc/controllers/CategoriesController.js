import CategoriesView from "../views/CategoriesView.js";
import CategoriesModel from "../model/CategoriesModel.js";

export default class CategoriesController {
    constructor() {
        this.model = new CategoriesModel();
        this.viewCategories = new CategoriesView();
    }

    async doAction(action, id) {
    switch (action) {

      case "getAll": {
        const categories = await this.model.getAll();
        console.log(categories)
        this.viewCategories.render(categories);
        break;
      }

      case "getById":{
        console.log("getById")

        const idSearch =  this.viewCategories.getidSearch();

        console.log(idSearch);

        const categories = await this.model.getById(idSearch);

        console.log(categories);

        this.viewCategories.render(categories);

        break;
      }
      case "getByName": {
        console.log("getByName")
        
        const nameSearch =  this.viewCategories.getTextSearch();

        console.log(nameSearch)

        const categories = await this.model.getByName(nameSearch);

        console.log(categories)

        this.viewCategories.render(categories);
        break;
      }

      case "crearCategoria":
        await this.viewCategories.renderCreate();
        break;

      case "insertCategoria":
        await this.model.insertCategoria(this.viewCategories.getCategory());
        this.doAction("getAll");
        break;

      case "editarCategoria": {
        const categories = await this.model.getById(id);
        console.log(categories)
        this.viewCategories.renderEdit(categories);
        break;
      }
     case "deleteCategoria":{
        
        const confirmado = confirm("¿Seguro que quieres eliminar esta categoria?");
        if (!confirmado) break;
      
        console.log("Eliminamos " + id);
        
        const eliminar = await this.model.deleteCategoria(id);
        if (eliminar) {
        alert("Categoria eliminado correctamente!");
        // Refresca la lista
         this.doAction("getAll")
        } else {
        alert("Error al eliminar la Categoria.");
    }
        break;

     }

     case "updateCategoria": {
    const categories = this.viewCategories.getCategory();
      
    const actualizado = await this.model.updateCategoria(categories);

    if (actualizado) {
        alert("Categoria actualizado correctamente!");
        // Refresca la lista
         this.doAction("getAll")
    } else {
        alert("Error al actualizar el producto.");
    }
    break;
}

    }
  }
}
