export default class Producte {
    constructor(id,id_categoria,name,cantidad,precio,descripcion,referencia) {
        this.id = id;
        this.id_categoria = id_categoria;
        this.name = name;
        this.cantidad = cantidad;
        this.precio = precio;
        this.descripcion = descripcion;
        this.referencia = referencia;
    }
    
}