let urlAPI = "http://localhost/simplemvc/server-api/productes.php";

export default class ProductesModel {
    constructor(apiUrl) {
        this.apiUrl = apiUrl; // URL base de la API
    }

async getAll()
    {
         try {

            console.log(urlAPI)
        const response = await fetch(urlAPI);

        if (!response.ok) {
            const errorObject = await response.json();
            console.log(errorObject.error);
            return;
        }

        const productes = await response.json();
        
        return productes;

    } catch (error) {
        console.log("Error de conexión:", error);
    }
    }

   // retorna el producte amb un ID
async getById(id)
{
    try {

        const response = await fetch(`${urlAPI}?id=${id}`);

        if (!response.ok) {
            const errorObject = await response.json();
            console.log(errorObject.error);
            return;
        }

        const producte = await response.json();
        return producte;

    } catch (error) {
        console.log("Error de conexión:", error);
    }
}


    // Elimina el producte amb l'ID
async    delete(id)
    {
        
    }

    // Retorna els productes que contenen NAME
async getByName(name)
{
    try {

        const response = await fetch(`${urlAPI}?name=${encodeURIComponent(name)}`);

        if (!response.ok) {
            const errorObject = await response.json();
            console.log(errorObject.error);
            return;
        }

        const productes = await response.json();
        return productes;

    } catch (error) {
        console.log("Error de conexión:", error);
    }
}


    // Inserta un producte
async   insertProducte(producte){  

    try{

        const response = await fetch(urlAPI, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                id:producte.id,
                id_categoria: producte.id_categoria,
                name: producte.name,
                cantidad: producte.cantidad,
                precio: producte.precio,
                descripcion: producte.descripcion,
                referencia: producte.referencia
            })
        });
        if (!response.ok) {
            console.log("not ok")
            const errorObject = await response.json();
            console.log(errorObject.error);
            return;
        }

        console.log("espero resposta")
        const data = await response.json();
        console.log("tinc resposta")
        return data; // 
   } catch (error) {
        console.log("Error de conexión:", error);
    }
}

// Actualiza un producto
async updateProducte(producte) {
    try {


        console.log("update producte")
        console.log(producte)
        console.log(urlAPI)
        
        const response = await fetch(urlAPI, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                id:producte.id,
                id_categoria: producte.id_categoria,
                name: producte.name,
                cantidad: producte.cantidad,
                precio: producte.precio,
                descripcion: producte.descripcion,
                referencia: producte.referencia
            })
        });

        if (!response.ok) {
            console.log("not ok")
            const errorObject = await response.json();
            console.log(errorObject.error);
            return;
        }

        console.log("espero resposta")
        const data = await response.json();
        console.log("tinc resposta")
        return data; // 

    } catch (error) {
        console.log("Error de conexión:", error);
    }
}


}

