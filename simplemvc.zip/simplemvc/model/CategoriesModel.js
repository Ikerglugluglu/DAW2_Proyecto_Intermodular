let urlAPI = "http://localhost/simplemvc/server-api/categorias.php";

export default class CategoriesModel {
 
   constructor(apiUrl) {
        this.apiUrl = apiUrl; // URL base de la API
    }
   async getAll()
    {
         try {

            console.log(urlAPI)
        const response = await fetch(urlAPI);

        if (!response.ok) {
            const errorObject = await response.json();
            console.log(errorObject.error);
            return;
        }

        const categorias = await response.json();
        
        return categorias;

    } catch (error) {
        console.log("Error de conexión:", error);
    }
    }

      // retorna el categoria amb un ID
async getById(id)
{
    try {

        const response = await fetch(`${urlAPI}?id=${id}`);

        if (!response.ok) {
            const errorObject = await response.json();
            console.log(errorObject.error);
            return;
        }

        const categorias = await response.json();
        return categorias;

    } catch (error) {
        console.log("Error de conexión:", error);
    }
}
async getByName(name)
{
    try {

        const response = await fetch(`${urlAPI}?name=${encodeURIComponent(name)}`);

        if (!response.ok) {
            const errorObject = await response.json();
            console.log(errorObject.error);
            return;
        }

        const categorias = await response.json();
        return categorias;

    } catch (error) {
        console.log("Error de conexión:", error);
    }
}
// Inserta una Categoria
async   insertCategoria(categoria){  

    try{

        const response = await fetch(urlAPI, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                id:categoria.id,
                name: categoria.name
            })
        });
        if (!response.ok) {
            console.log("not ok")
            const errorObject = await response.json();
            console.log(errorObject.error);
            return;
        }

        console.log("espero resposta")
        const data = await response.json();
        console.log("tinc resposta")
        return data; // 
   } catch (error) {
        console.log("Error de conexión:", error);
    }
}
// Actualiza una categoria
async updateCategoria(categoria) {
    try {


        console.log("update categoria")
        console.log(categoria)
        console.log(urlAPI)
        
        const response = await fetch(urlAPI, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                id:categoria.id,
                name: categoria.name
            })
        });

        if (!response.ok) {
            console.log("not ok")
            const errorObject = await response.json();
            console.log(errorObject.error);
            return;
        }

        console.log("espero resposta")
        const data = await response.json();
        console.log("tinc resposta")
        return data; // 

    } catch (error) {
        console.log("Error de conexión:", error);
    }
}
// Elimina el categoria amb l'ID
async  deleteCategoria(categoriaID)
    {
        try{
            console.log("delete categoria")
            console.log(categoriaID)

        const response = await fetch(urlAPI, {
            method: "DELETE",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                id:categoriaID
            })
        });
        if (!response.ok) {
            console.log("not ok")
            const errorObject = await response.json();
            console.log(errorObject.error);
            return;
        }

        console.log("espero resposta")
        const data = await response.json();
        console.log("tinc resposta")
        return data; // 
   } catch (error) {
        console.log("Error de conexión:", error);
    }
}

}