export default class CategoriesModel {
    constructor() {
    }

    getAll(){

        return null;
    }
}