export default class View {
    constructor() {
      
    }
  
    init() {// inicializa la vista, si es necesario
        			
    }
    render()
    {

    }

}
