import replaceParams from "../utils/replaceParams.js";

export default class HomeView {
  constructor() {
    this.plantilla = null;
  }

  // Carrega la plantilla del servidor si no està ja carregada
  async loadTemplate() {
    if (!this.plantilla) {
      const response = await fetch("./views/home.html");
      this.plantilla = await response.text();
    }
  }

  async render(textHome) {
    try {
     
      // Primer s'assegura de que la plantilla està carregada
      await this.loadTemplate();
      // Reemplaça els paràmetres pels que li passen (això podria vindre de BD/API)
      document.getElementById("mvc-main").innerHTML = replaceParams.replace(textHome, this.plantilla);
    } catch (err) {
      document.getElementById("mvc-main").textContent = "Something went wrong...";
      console.error(err);
    }
  }
}
