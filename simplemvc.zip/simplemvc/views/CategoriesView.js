export default class CategoriesView {
    constructor() {
      
    }
  
    init() {// inicializa la vista, si es necesario
       		
    }

    render()
    {
        console.log("Falta implementar categories...")
        document.getElementById("mvc-main").innerHTML="<h2>TEXT DE CATEGORIES</h2>"
    }

}
