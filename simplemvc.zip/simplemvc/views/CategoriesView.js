export default class CategoriesView {
    constructor() { 
      this.plantilla = null;
    }
  
     async loadTemplate() {
    if (!this.plantilla) {
      const response = await fetch("./views/categories.html");
      this.plantilla = await response.text();
    }
  }

  async render(categories) {
    await this.loadTemplate();

    const container = document.getElementById("mvc-main");
    container.innerHTML = this.plantilla;

// Creem la taula de categories
    let result = "<table class='tableCategories'>";
    result += "<tr>";
    result += "<th>ID</th>";
    result += "<th>Name</th>";
    result += "<th>EDIT</th>";
    result += "</tr>";
    
    await categories.forEach(categoria => {
              result += "<tr>";
      result += "<td>" + categoria.id + "</td>";
      result += "<td>" + categoria.name + "</td>";
      result += "<td>";
      result += "<button ";
      result += "data-mvcid='" + categoria.id + "' ";
      result += "class='mvc-clickable' ";
      result += "name='editarCategoria'>";
      result += "Edit";
      result += "</button>";
      result += "<button ";
      result += "data-mvcid='" + categoria.id + "' ";
      result += "class='mvc-clickable' ";
      result += "name='deleteCategoria'>";
      result += "DELETE";
      result += "</button>";
      result += "</td>";
      result += "</tr>";

    });
    result += "</table>";

    // Afegim la taula a la vista
    container.innerHTML += result;
  }

// Getters
getTextSearch() {
    return document.getElementById("txtNameSearch").value;
  }


}
