import Categoria from "../model/Categoria.js";

export default class CategoriaView {
  constructor() {
    this.plantilla = null;
  }

  async loadTemplate() {
    if (!this.plantilla) {
      const response = await fetch("./views/categoria.html");
      this.plantilla = await response.text();
    }
  }

  // Render per a crear un nou categoria
  async renderCreate() {
    await this.loadTemplate();

    const container = document.getElementById("mvc-main");
    container.innerHTML = this.plantilla;

    // Personalizamos el título
    document.getElementById("categoriaTitol").textContent = "New categoria";

    // Desactivar ID
    document.getElementById("id").disabled = true;

}
  // Render per a editar un categoria existent
  async renderEdit(categoria) {
    await this.loadTemplate();

    console.log(categoria)
    const container = document.getElementById("mvc-main");
    container.innerHTML = this.plantilla;

    document.getElementById("categoriaTitol").textContent = "Editar categoria";
    document.getElementById("saveCategoria").name = "updateCategoria";

    document.getElementById("id").value = categoria.id;
    document.getElementById("name").value = categoria.name;

}

  // Retornarà l'estat de la vista (un categoria)
  getCategoria() {
    const categoria = new Categoria();

    categoria.id = document.getElementById("id").value;
    categoria.name = document.getElementById("name").value;
    

    return categoria;
}



}
