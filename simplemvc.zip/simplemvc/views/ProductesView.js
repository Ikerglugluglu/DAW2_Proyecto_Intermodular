export default class ProductesView {
  constructor() {
    this.plantilla = null;
  }

  async loadTemplate() {
    if (!this.plantilla) {
      const response = await fetch("./views/productes.html");
      this.plantilla = await response.text();
    }
  }

  async render(productes) {
    await this.loadTemplate();

    const container = document.getElementById("mvc-main");
    container.innerHTML = this.plantilla;

    // Creem la taula de productes
    let result = "<table class='tableProductes'>";
    result += "<tr>";
    result += "<th>ID</th>";
    result += "<th>Name</th>";
    result += "<th>PVP</th>";
    result += "<th>EDIT</th>";
    result += "</tr>";

   await productes.forEach(producte => {
      result += "<tr>";
      result += "<td>" + producte.id + "</td>";
      result += "<td>" + producte.name + "</td>";
      result += "<td>" + producte.precio + "€</td>";
      result += "<td>";
      result += "<button ";
      result += "data-mvcid='" + producte.id + "' ";
      result += "class='mvc-clickable' ";
      result += "name='editarProducte'>";
      result += "Edit";
      result += "</button>";
      result += "</td>";
      result += "</tr>";
    });

    result += "</table>";

    // Afegim la taula a la vista
    container.innerHTML += result;
  }

  // Retornarà el text a buscar
  getTextSearch() {
    return document.getElementById("txtNameSearch").value;
  }

  // Retornarà el text a buscar
  getidSearch() {
    return document.getElementById("txtIdSearch").value;
  }
}
