import Producte from "../model/Producte.js";

export default class ProducteView {
  constructor() {
    this.plantilla = null;
  }

  async loadTemplate() {
    if (!this.plantilla) {
      const response = await fetch("./views/producte.html");
      this.plantilla = await response.text();
    }
  }


  
  // Render per a crear un nou producte
  async renderCreate() {
    await this.loadTemplate();

    const container = document.getElementById("mvc-main");
    container.innerHTML = this.plantilla;

    // Personalizamos el título
    document.getElementById("productesTitol").textContent = "New producte";

    // Desactivar ID
    document.getElementById("id").disabled = true;

}


  // Render per a editar un producte existent
  async renderEdit(producte) {
    await this.loadTemplate();

    const container = document.getElementById("mvc-main");
    container.innerHTML = this.plantilla;

    document.getElementById("productesTitol").textContent = "Editar producte";
    document.getElementById("saveProducte").name = "updateProducte";

    document.getElementById("id").value = producte.id;
    document.getElementById("id_categoria").value = producte.id_categoria;
    document.getElementById("name").value = producte.name;
    document.getElementById("cantidad").value = producte.cantidad;
    document.getElementById("precio").value = producte.precio;
    document.getElementById("descripcion").value = producte.descripcion;
    document.getElementById("referencia").value = producte.referencia;

}



  // Retornarà l'estat de la vista (un producte)
getProducte() {
    const producte = new Producte();

    producte.id = document.getElementById("id").value;
    producte.id_categoria = document.getElementById("id_categoria").value;
    producte.name = document.getElementById("name").value;
    producte.cantidad = document.getElementById("cantidad").value;
    producte.precio = document.getElementById("precio").value;
    producte.descripcion = document.getElementById("descripcion").value;
    producte.referencia = document.getElementById("referencia").value;

    return producte;
}



}
