import Producte from "../model/Producte.js";

export default class ProducteView {
  constructor() {
    this.plantilla = null;
  }

  async loadTemplate() {
    if (!this.plantilla) {
      const response = await fetch("./views/producte.html");
      this.plantilla = await response.text();
    }
  }


  
  // Render per a crear un nou producte
async renderCreate(categories) {
    await this.loadTemplate();

    const container = document.getElementById("mvc-main");
    container.innerHTML = this.plantilla;

    document.getElementById("productesTitol").textContent = "New producte";
    document.getElementById("id").disabled = true;

    // Cambiamos input numérico por select dinámico
    const categoriaInput = document.getElementById("id_categoria");
    categoriaInput.outerHTML = `<select id="id_categoria" class="form-control" required></select>`;
    const select = document.getElementById("id_categoria");

    for (const cat of categories) {
        select.innerHTML += `<option value="${cat.id}">${cat.name}</option>`;
    }
}


  // Render per a editar un producte existent
  async renderEdit(producte, categories) {
    await this.loadTemplate();

    const container = document.getElementById("mvc-main");
    container.innerHTML = this.plantilla;

    document.getElementById("productesTitol").textContent = "Editar producte";
    document.getElementById("saveProducte").name = "updateProducte";

    document.getElementById("id").value = producte.id;
    document.getElementById("id").disabled = true;

    // Cambiamos input por select dinámico
    const categoriaInput = document.getElementById("id_categoria");
    categoriaInput.outerHTML = `<select id="id_categoria" class="form-control" required></select>`;
    const select = document.getElementById("id_categoria");

    for (const cat of categories) {
        const selected = cat.id === producte.id_categoria ? "selected" : "";
        select.innerHTML += `<option value="${cat.id}" ${selected}>${cat.name}</option>`;
    }

    document.getElementById("name").value = producte.name;
    document.getElementById("cantidad").value = producte.cantidad;
    document.getElementById("precio").value = producte.precio;
    document.getElementById("descripcion").value = producte.descripcion;
    document.getElementById("referencia").value = producte.referencia;
}


  // Retornarà l'estat de la vista (un producte)
getProducte() {
    const producte = new Producte();

    producte.id = document.getElementById("id").value;
    producte.id_categoria = document.getElementById("id_categoria").value;
    producte.name = document.getElementById("name").value;
    producte.cantidad = document.getElementById("cantidad").value;
    producte.precio = document.getElementById("precio").value;
    producte.descripcion = document.getElementById("descripcion").value;
    producte.referencia = document.getElementById("referencia").value;

    return producte;
}



}
