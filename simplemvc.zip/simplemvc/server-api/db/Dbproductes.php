<?php

class DbProductes
{
    private $pdo; // Variable per a la connexió PDO

    // Constructor: inicializa la conexió a la bbdd
    public function __construct()
    {
        // Inclou l'arxiu de configuració
        $config = include 'dbConf.php';

        try {
            $this->pdo = new PDO( "mysql:host={$config['db_host']};dbname={$config['db_name']}",
                                   $config['db_user'],
                                   $config['db_pass']);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (Exception $e) {
            throw new Exception("Error al conectar con la base de datos: " . $e->getMessage());
        }
    }

    // Retorna tots els productes
    public function getAll()
    {
            $stmt = $this->pdo->query('SELECT * FROM productos');
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Retorna els producte per grup
    public function getProductosCategory($id_categoria)
    {
        $stmt = $this->pdo->prepare('SELECT * FROM productos WHERE id_categoria = :id_categoria');
        $stmt->bindParam(':id_categoria', $id_categoria, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Retorna producte amb l'id
    public function  getById($id)
    {
        $stmt = $this->pdo->prepare('SELECT * FROM productos WHERE id = :id');
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC); // Devuelve un único registro
    }
   public function  getByName($name)
    {
        $name="%".$name."%";
        $stmt = $this->pdo->prepare('SELECT * FROM productos WHERE name LIKE :name');
        $stmt->bindParam(':name', $name, PDO::PARAM_STR);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC); // Devuelve un único registro
    }
    // Inserta nou productos
    public function insert($id_categoria, $name, $cantidad, $precio, $descripcion, $referencia )
    {
        $stmt = $this->pdo->prepare('INSERT INTO productos (id_categoria, name,cantidad,precio,descripcion,referencia) VALUES (:id_categoria, :name, :cantidad,:precio,:descripcion,:referencia)');
        $stmt->bindParam(':id_categoria', $id_categoria, PDO::PARAM_INT);
		$stmt->bindParam(':name', $name, PDO::PARAM_STR);
		$stmt->bindParam(':cantidad', $cantidad, PDO::PARAM_INT);
		$stmt->bindParam(':precio', $precio); // DECIMAL → sin PARAM_STR/INT
		$stmt->bindParam(':descripcion', $descripcion, PDO::PARAM_STR);
		$stmt->bindParam(':referencia', $referencia, PDO::PARAM_STR);
        return $stmt->execute(); // Retorna true si la actualizació s'ha executat amb èxit
    }

    // Actualitza producto
    public function update($id, $id_categoria, $name, $cantidad, $precio, $descripcion, $referencia)
{
    $stmt = $this->pdo->prepare(
        'UPDATE productos
         SET
            id_categoria = :id_categoria,
            name = :name,
            cantidad = :cantidad,
            precio = :precio,
            descripcion = :descripcion,
            referencia = :referencia
         WHERE id = :id'
    );

    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->bindParam(':id_categoria', $id_categoria, PDO::PARAM_INT);
    $stmt->bindParam(':name', $name, PDO::PARAM_STR);
    $stmt->bindParam(':cantidad', $cantidad, PDO::PARAM_INT);
    $stmt->bindParam(':precio', $precio); // DECIMAL
    $stmt->bindParam(':descripcion', $descripcion, PDO::PARAM_STR);
    $stmt->bindParam(':referencia', $referencia, PDO::PARAM_STR);

    return $stmt->execute();
}


    // Elimina productos per ID
    public function delete($id)
    {
        $stmt = $this->pdo->prepare('DELETE FROM productos WHERE id = :id');
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        return $stmt->execute(); // Retorna true si la actualizació s'ha executat amb èxit
    }
}
