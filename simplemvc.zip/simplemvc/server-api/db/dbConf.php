<?php
return [
    'db_host' => 'localhost',      // Host de la base de datos
    'db_name' => 'botiga',    // Nombre de la base de datos
    'db_user' => 'admin',        // Usuario
    'db_pass' => 'admin',     // Contraseña
];
?>
