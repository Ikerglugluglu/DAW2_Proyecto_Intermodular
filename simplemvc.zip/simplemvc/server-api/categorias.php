<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Allow: GET, POST, PUT, DELETE');

require 'db/DbCategorias.php'; // Clase que crearemos para la DB

// Función para leer datos enviados en POST/PUT/DELETE
function getData() {
    $contentType = $_SERVER['CONTENT_TYPE'] ?? '';

    if (strpos($contentType, 'application/json') !== false) {
        $data = json_decode(file_get_contents('php://input'), true);
    } elseif (strpos($contentType, 'application/x-www-form-urlencoded') !== false) {
        parse_str(file_get_contents('php://input'), $data);
    } else {
        header('HTTP/1.1 400 Bad Request');
        echo json_encode(['error' => 'Unsupported Content-Type']);
        exit;
    }

    return $data;
}

// Conexión a la base de datos
try {
    $db = new DbCategorias();
} catch (Exception $e) {
    header('HTTP/1.1 500 Internal Server Error');
    echo json_encode(['error' => 'Error en la conexión a la base de datos']);
    exit;
}

// Detectamos el método HTTP
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {

    case 'GET':
        try {
            if (isset($_GET['id'])) {
                // Categoría por ID
                $categoria = $db->getById((int)$_GET['id']);
                echo json_encode($categoria ?: ['error' => 'Categoría no encontrada']);
            } else if (isset($_GET['name'])){
                 $categoria = $db->getByNAme((string)$_GET['name']);
                 echo json_encode($categoria ?: ['error' => 'Categoria no encontrado']);
            
            }else {
                // Todas las categorías
                $categorias = $db->getAll();
                echo json_encode($categorias);
            }
        } catch (Exception $e) {
            header('HTTP/1.1 500 Internal Server Error');
            echo json_encode(['error' => 'Error al consultar categorías']);
        }
        break;

    case 'POST':
        try {
            $data = getData();
            if (!isset($data['name']) || empty(trim($data['name']))) {
                header('HTTP/1.1 400 Bad Request');
                echo json_encode(['error' => 'El campo name es obligatorio']);
                exit;
            }
            $response = $db->insert($data['name']);
            echo json_encode(['success' => $response]);
        } catch (Exception $e) {
            header('HTTP/1.1 500 Internal Server Error');
            echo json_encode(['error' => 'Error insertando categoría: ' . $e->getMessage()]);
        }
        break;

    case 'PUT':
        try {
            $data = getData();
            if (!isset($data['id'])) {
                header('HTTP/1.1 400 Bad Request');
                echo json_encode(['error' => 'id es obligatorio']);
                exit;
            }
            if (!isset($data['name']) || empty(trim($data['name']))) {
                header('HTTP/1.1 400 Bad Request');
                echo json_encode(['error' => 'El campo name es obligatorio']);
                exit;
            }
            $response = $db->update((int)$data['id'], $data['name']);
            echo json_encode(['success' => $response]);
        } catch (Exception $e) {
            header('HTTP/1.1 500 Internal Server Error');
            echo json_encode(['error' => 'Error actualizando categoría: ' . $e->getMessage()]);
        }
        break;

    case 'DELETE':
        try {
            $data = getData();
            if (!isset($data['id'])) {
                header('HTTP/1.1 400 Bad Request');
                echo json_encode(['error' => 'ID de categoría requerido']);
                exit;
            }
            $response = $db->delete((int)$data['id']);
            echo json_encode(['success' => $response]);
        } catch (Exception $e) {
            header('HTTP/1.1 500 Internal Server Error');
            echo json_encode(['error' => 'Error eliminando categoría: ' . $e->getMessage()]);
        }
        break;

    default:
        header('HTTP/1.1 405 Method Not Allowed');
        header('Allow: GET, POST, PUT, DELETE');
        echo json_encode(['error' => 'Método no permitido']);
        break;
}
