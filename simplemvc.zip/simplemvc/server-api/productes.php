<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Allow: GET, POST, PUT, DELETE');

require 'db/Dbproductes.php';

// Función para leer datos enviados en POST/PUT/DELETE
function getData() {
    $contentType = $_SERVER['CONTENT_TYPE'] ?? '';

    if (strpos($contentType, 'application/json') !== false) {
        $data = json_decode(file_get_contents('php://input'), true);
    } elseif (strpos($contentType, 'application/x-www-form-urlencoded') !== false) {
        parse_str(file_get_contents('php://input'), $data);
    } else {
        header('HTTP/1.1 400 Bad Request');
        echo json_encode(['error' => 'Unsupported Content-Type']);
        exit;
    }

    return $data;
}

// Conexión a la base de datos
try {
    $db = new DbProductes();
} catch (Exception $e) {
    header('HTTP/1.1 500 Internal Server Error');
    echo json_encode(['error' => 'Error en la conexión a la base de datos']);
    exit;
}

// Detectamos el método HTTP
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {

    case 'GET':
        try {
            if (isset($_GET['id'])) {
                // Producto por ID
                $producto = $db->getById((int)$_GET['id']);
                echo json_encode($producto ?: ['error' => 'Producto no encontrado']);
            }
            else if (isset($_GET['name'])){
                 $producto = $db->getByNAme((string)$_GET['name']);
                 echo json_encode($producto ?: ['error' => 'Producto no encontrado']);

            }  else if (isset($_GET['categoryName'])) {
                // Productos por nombre de categoría
                $productos = $db->getProductosByCategoryName((string)$_GET['categoryName']);
                echo json_encode($productos ?: ['error' => 'No se encontraron productos en esa categoría']);
                
                
            }else if (isset($_GET['minPrice']) && isset($_GET['maxPrice'])) {

                $minPrice = (float) $_GET['minPrice'];
                $maxPrice = (float) $_GET['maxPrice'];

                 $productos = $db->getByPriceRange($minPrice, $maxPrice);
                echo json_encode($productos ?: ['error' => 'No hay productos en ese rango']);

            }else {
                // Todos los productos
                $productos = $db->getAll();
                echo json_encode($productos);
            }
        } catch (Exception $e) {
            header('HTTP/1.1 500 Internal Server Error');
            echo json_encode(['error' => 'Error al consultar productos']);
        }
        break;

    case 'POST':
        try {
            $data = getData();
            // id_categoria opcional
            $id_categoria = isset($data['id_categoria']) ? (int)$data['id_categoria'] : null;

            $response = $db->insert(
                $id_categoria,
                $data['name'] ?? '',
                $data['cantidad'] ?? 0,
                $data['precio'] ?? 0,
                $data['descripcion'] ?? '',
                $data['referencia'] ?? ''
            );
            echo json_encode(['success' => $response]);
        } catch (Exception $e) {
            header('HTTP/1.1 500 Internal Server Error');
            echo json_encode(['error' => 'Error insertando producto: ' . $e->getMessage()]);
        }
        break;

    case 'PUT':
        try {
            $data = getData();
            error_log(print_r($data, true));
            if (!isset($data['id'])) {
                header('HTTP/1.1 400 Bad Request');
                echo json_encode(['error' => 'id es obligatorio']);
                exit;
            }

            // id_categoria opcional
            $id_categoria = isset($data['id_categoria']) ? (int)$data['id_categoria'] : null;

            $response = $db->update(
                (int)$data['id'],
                $id_categoria,
                $data['name'] ?? '',
                $data['cantidad'] ?? 0,
                $data['precio'] ?? 0,
                $data['descripcion'] ?? '',
                $data['referencia'] ?? ''
            );
            echo json_encode(['success' => $response]);
        } catch (Exception $e) {
            header('HTTP/1.1 500 Internal Server Error');
            echo json_encode(['error' => 'Error actualizando producto: ' . $e->getMessage()]);
        }
        break;

    case 'DELETE':
        try {
            $data = getData();
            if (!isset($data['id'])) {
                header('HTTP/1.1 400 Bad Request');
                echo json_encode(['error' => 'ID de producto requerido']);
                exit;
            }
            $response = $db->delete((int)$data['id']);
            echo json_encode(['success' => $response]);
        } catch (Exception $e) {
            header('HTTP/1.1 500 Internal Server Error');
            echo json_encode(['error' => 'Error eliminando producto: ' . $e->getMessage()]);
        }
        break;

    default:
        header('HTTP/1.1 405 Method Not Allowed');
        header('Allow: GET, POST, PUT, DELETE');
        echo json_encode(['error' => 'Método no permitido']);
        break;
}


