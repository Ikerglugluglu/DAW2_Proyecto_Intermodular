import MainController from "./controllers/MainController.js";

var myController;

/* EN L'INDEX CONTROLAREM L'ENRUTAMENT DE LES DIFERENTS ACCIONS
CREANT UN CONTROLADOR PRINCIPAL I PASSANT-LI L'ACCIÓ PER A QUE LA GESTIONE
EN PRINCIPI NO HAURIEM DE MODIFICAR RES AQUÍ
*/


// Quan el document estigue carregat
document.addEventListener("DOMContentLoaded", () => {
  
    //Creo el controlador

    myController = new MainController;
    myController.doAction("home"); // Acció per defecte


    // Afegim un event listener per controlar els clicks dels elements de la classe mvc-clickable

    document.addEventListener("click", function(event) {
    const element = event.target;
    // Només ens interessa si té la classe mvc-clickable
    if (!element.classList.contains("mvc-clickable")) return;
   
    // Cancelem l'acció per defecte
    event.preventDefault();

    // Enrutarem segons el nom del botó i li passem si té el paràmetre mvcid
    route(element.name, element.dataset.mvcid);
});

});


function route(action,id)
{
    // Passem la responsabilitat al controlador
        myController.doAction(action,id)
}


