// index.js: inicializa el controlador principal y el enrutado por clicks
import MainController from "./controller/MainController.js";

let myController;

// Cuando el DOM esté listo
document.addEventListener("DOMContentLoaded", () => {
    // Creamos el controlador principal
    myController = new MainController();
    myController.doAction("home"); // Acción por defecto
    myController.doAction("refreshAuthUI");

    // Escuchamos todos los clicks de elementos con clase mvc-clickable
    document.addEventListener("click", function(event) {
        const element = event.target;

        if (!element.classList.contains("mvc-clickable")) return;

        event.preventDefault();

        // Enrutamos según el nombre y, si tiene, el id del elemento
        route(element.name, element.dataset.mvcid);
    });
});

function route(action, id) {
    myController.doAction(action, id);
}
