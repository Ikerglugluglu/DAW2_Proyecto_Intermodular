<?php
// Cerrar sesión
session_start();
session_destroy();
echo "Sesión cerrada correctamente";
?>
