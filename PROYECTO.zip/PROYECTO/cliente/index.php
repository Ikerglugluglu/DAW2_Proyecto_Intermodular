<?php
include '../control/roles.php';

// Solo accesible a cliente
checkRole('cliente');

echo "Perfil de usuario: " . $_SESSION['nombre'];
?>
<form action="/PROYECTO/auth/go_index.php" method="post">
    <button type="submit">Inicio</button>
</form>
