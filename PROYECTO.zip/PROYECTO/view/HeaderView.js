// HeaderView: controla la visibilidad del menu superior segun sesion
export default class HeaderView {
    update(session) {
        const btnLogin = document.getElementById("btnLogin");
        const btnRegister = document.getElementById("btnRegister");
        const userMenu = document.getElementById("userMenu");
        const usersMenu = document.getElementById("menu2");

        if (!btnLogin || !btnRegister || !userMenu) {
            return;
        }

        if (session && session.logged) {
            btnLogin.classList.add("d-none");
            btnRegister.classList.add("d-none");
            userMenu.classList.remove("d-none");

            if (usersMenu) {
                if (session.user && session.user.rol === "cliente") {
                    usersMenu.classList.add("d-none");
                } else {
                    usersMenu.classList.remove("d-none");
                }
            }
        } else {
            btnLogin.classList.remove("d-none");
            btnRegister.classList.remove("d-none");
            userMenu.classList.add("d-none");

            if (usersMenu) {
                usersMenu.classList.add("d-none");
            }
        }
    }
}
