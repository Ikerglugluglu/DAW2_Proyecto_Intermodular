// UsersView: renderizado de la tabla y formularios de usuarios
import User from "../model/User.js";

export default class UsersView {
    constructor() {
        this.plantillaList = null;
        this.plantillaForm = null;
    }

    /* ===================== CARGA TEMPLATES ===================== */

    async loadListTemplate() {
        if (!this.plantillaList) {
            const response = await fetch("./html/users.html");
            this.plantillaList = await response.text();
        }
    }

    async loadFormTemplate() {
        if (!this.plantillaForm) {
            const response = await fetch("./html/user.html");
            this.plantillaForm = await response.text();
        }
    }

    /* ===================== RENDER LIST ===================== */

    async renderList(users, role = null, userId = null, page = 1, pageSize = 50) {
        await this.loadListTemplate();
        const container = document.getElementById("mvc-main");
        container.innerHTML = this.plantillaList;

        this.applyPermissionsToHeader(role);

        if (!users) {
            container.innerHTML += "<p>No hay usuarios para mostrar.</p>";
            return;
        }

        if (!Array.isArray(users)) {
            if (users.error) {
                container.innerHTML += "<p>" + users.error + "</p>";
                return;
            }
            users = [users];
        }

        const showAdminCols = role === "admin";
        // Filtrar para cliente: solo su propio registro
        if (role === "cliente") {
            users = users.filter(u => Number(u.id) === Number(userId));
        }

        // Paginacion
        const total = users.length;
        const totalPages = Math.max(1, Math.ceil(total / pageSize));
        let currentPage = page;
        if (currentPage < 1) {
            currentPage = 1;
        }
        if (currentPage > totalPages) {
            currentPage = totalPages;
        }
        const start = (currentPage - 1) * pageSize;
        const end = start + pageSize;
        const pageItems = users.slice(start, end);

        let html = "<table class='tableUsers'>";
        html += "<tr>";
        html += "<th>ID</th><th>Nombre</th><th>Email</th>";
        if (showAdminCols) {
            html += "<th>Rol</th><th>Activo</th>";
        }
        html += "<th>Acciones</th>";
        html += "</tr>";

       pageItems.forEach(user => {
            html += "<tr>";
            html += "<td>" + user.id + "</td>";
            html += "<td>" + user.nombre + "</td>";
            html += "<td>" + user.email + "</td>";
            if (showAdminCols) {
                html += "<td>" + (user.rol || "") + "</td>";
                if (user.activo == 1) {
                    html += "<td>Sí</td>";
                } else {
                    html += "<td>No</td>";
                }
            }

            html += "<td>";

            if (role === "admin" || role === "empleado" || role === "cliente") {
                html += "<button class='mvc-clickable' name='editarUser' data-mvcid='" + user.id + "'>Editar</button>";
            }

            if (role === "admin") {
                if (user.activo == 1) {
                    html += "<button class='mvc-clickable' name='deactivateUser' data-mvcid='" + user.id + "'>Desactivar</button>";
                } else {
                    html += "<button class='mvc-clickable' name='activateUser' data-mvcid='" + user.id + "'>Activar</button>";
                }
            }

            html += "</td>";
            html += "</tr>";
});

        html += "</table>";

        container.innerHTML += html;

        // Controles de paginacion
        if (totalPages > 1) {
            const pager = document.createElement("div");
            pager.classList.add("d-flex", "gap-2", "mt-3", "flex-wrap");

            for (let i = 1; i <= totalPages; i += 1) {
                const btn = document.createElement("button");
                btn.classList.add("mvc-clickable");
                btn.setAttribute("name", "usersPage");
                btn.setAttribute("data-mvcid", String(i));
                btn.textContent = "Pagina " + i;
                if (i === currentPage) {
                    btn.disabled = true;
                }
                pager.appendChild(btn);
            }

            container.appendChild(pager);
        }

        if (role === "admin") {
            const btnCrear = document.createElement("button");
            btnCrear.textContent = "Crear Nuevo Usuario";
            btnCrear.classList.add("mvc-clickable");
            btnCrear.setAttribute("name", "crearUser");
            container.appendChild(btnCrear);
        }
    }

    /* ===================== RENDER CREATE ===================== */

    async renderForm(user, role = null) {
    const container = document.getElementById("mvc-main");

    for (let attempt = 0; attempt < 2; attempt += 1) {
        await this.loadFormTemplate();
        container.innerHTML = this.plantillaForm;
        const confirmInput = document.getElementById("passwordConfirm");
        if (confirmInput || attempt === 1) {
            break;
        }
        this.plantillaForm = null;
    }

    // Si user existe, estamos editando
    if (user) {
        document.getElementById("usersTitle").textContent = "Editar usuario";
        document.getElementById("saveUser").name = "updateUser";

        document.getElementById("id").value = user.id;
        document.getElementById("nombre").value = user.nombre;
        document.getElementById("email").value = user.email;
        document.getElementById("rol").value = user.rol;
        document.getElementById("activo").value = user.activo;
    } else {
        // Nuevo usuario
        document.getElementById("usersTitle").textContent = "Nuevo usuario";
        document.getElementById("saveUser").name = "insertUser";

        document.getElementById("id").value = "";
        document.getElementById("nombre").value = "";
        document.getElementById("email").value = "";
        document.getElementById("rol").value = "cliente";
        document.getElementById("activo").value = 1;
    }

    // Campos comunes
    document.getElementById("id").disabled = true;
    document.getElementById("password").value = ""; // Nunca rellenamos contraseña

    this.applyPermissionsToForm(role);

    const changePassword = document.getElementById("changePassword");
    const passwordInput = document.getElementById("password");
    const confirmInput = document.getElementById("passwordConfirm");
    const saveButton = document.getElementById("saveUser");

    if (changePassword && passwordInput && confirmInput && saveButton) {
        if (saveButton.name === "insertUser") {
            changePassword.checked = true;
            passwordInput.disabled = false;
            confirmInput.disabled = false;
        } else {
            changePassword.checked = false;
            passwordInput.disabled = true;
            confirmInput.disabled = true;
        }

        changePassword.addEventListener("change", () => {
            if (changePassword.checked) {
                passwordInput.disabled = false;
                confirmInput.disabled = false;
            } else {
                passwordInput.value = "";
                passwordInput.disabled = true;
                confirmInput.value = "";
                confirmInput.disabled = true;
            }
        });
    }
}


    // Para compatibilidad con tu código anterior
    async renderCreate() {
        return this.renderForm(null);
    }

    async renderEdit(user) {
        return this.renderForm(user);
    }

    /* ===================== GETTERS ===================== */

    getFormData() {
        this.clearValidation();

        const user = new User();
        user.id = document.getElementById("id").value;
        user.nombre = document.getElementById("nombre").value;
        user.email = document.getElementById("email").value;
        user.password = document.getElementById("password").value;
        const confirmInput = document.getElementById("passwordConfirm");
        const passwordConfirm = confirmInput ? confirmInput.value : "";
        user.rol = document.getElementById("rol").value;
        user.activo = Number(document.getElementById("activo").value);

        const saveButton = document.getElementById("saveUser");
        const changePassword = document.getElementById("changePassword");

        let hasErrors = false;
        const messages = [];

        if (!user.nombre || user.nombre.trim() === "") {
            this.setFieldInvalid("nombre", "nombreError", "El nombre es obligatorio");
            hasErrors = true;
            messages.push("El nombre es obligatorio");
        }

        if (!user.email || user.email.trim() === "") {
            this.setFieldInvalid("email", "emailError", "El email es obligatorio");
            hasErrors = true;
            messages.push("El email es obligatorio");
        } else {
            if (!this.isEmailAllowed(user.email)) {
                this.setFieldInvalid("email", "emailError", "El email debe ser @gmail.com o @hotmail.es");
                hasErrors = true;
                messages.push("El email debe ser @gmail.com o @hotmail.es");
            }
        }

        if (saveButton && saveButton.name === "insertUser") {
            if (!user.password || user.password === "") {
                this.setFieldInvalid("password", "passwordError", "La contraseña es obligatoria");
                hasErrors = true;
                messages.push("La contraseña es obligatoria");
            }
            if (!passwordConfirm || passwordConfirm === "") {
                this.setFieldInvalid("passwordConfirm", "passwordConfirmError", "Repite la contraseña");
                hasErrors = true;
                messages.push("Repite la contraseña");
            }
            if (user.password && passwordConfirm && user.password !== passwordConfirm) {
                this.setFieldInvalid("passwordConfirm", "passwordConfirmError", "Las contraseñas no coinciden");
                hasErrors = true;
                messages.push("Las contraseñas no coinciden");
            }
        } else {
            if (changePassword && changePassword.checked) {
                if (!user.password || user.password === "") {
                    this.setFieldInvalid("password", "passwordError", "La contraseña es obligatoria");
                    hasErrors = true;
                    messages.push("La contraseña es obligatoria");
                }
                if (!passwordConfirm || passwordConfirm === "") {
                    this.setFieldInvalid("passwordConfirm", "passwordConfirmError", "Repite la contraseña");
                    hasErrors = true;
                    messages.push("Repite la contraseña");
                }
                if (user.password && passwordConfirm && user.password !== passwordConfirm) {
                    this.setFieldInvalid("passwordConfirm", "passwordConfirmError", "Las contraseñas no coinciden");
                    hasErrors = true;
                    messages.push("Las contraseñas no coinciden");
                }
            } else {
                delete user.password;
            }
        }

        if (hasErrors) {
            this.showAlert(messages);
            return null;
        }

        return user;
    }

    getTextSearch() {
    const input = document.getElementById("txtNameSearch");

    if (input !== null) {
        return input.value;
    }

    return "";
}

    applyPermissionsToHeader(role) {
        const createButton = document.getElementById("btnCreateUser");
        const searchBox = document.getElementById("usersSearch");

        if (createButton && role !== "admin") {
            createButton.style.display = "none";
        }

        if (searchBox && role === "cliente") {
            searchBox.style.display = "none";
        }
    }

    applyPermissionsToForm(role) {
        const rolSelect = document.getElementById("rol");
        const activoSelect = document.getElementById("activo");
        const passwordInput = document.getElementById("password");
        const confirmInput = document.getElementById("passwordConfirm");
        const emailInput = document.getElementById("email");
        const changePassword = document.getElementById("changePassword");

        if (role === "cliente") {
            if (rolSelect) {
                rolSelect.disabled = true;
            }
            if (activoSelect) {
                activoSelect.disabled = true;
            }
            if (passwordInput) {
                passwordInput.disabled = true;
            }
            if (confirmInput) {
                confirmInput.disabled = true;
            }
            if (changePassword) {
                changePassword.disabled = true;
            }
            if (emailInput) {
                emailInput.disabled = true;
            }
        }

        if (role === "empleado") {
            if (rolSelect) {
                rolSelect.disabled = true;
            }
            if (activoSelect) {
                activoSelect.disabled = true;
            }
            if (passwordInput) {
                passwordInput.disabled = true;
            }
            if (confirmInput) {
                confirmInput.disabled = true;
            }
            if (changePassword) {
                changePassword.disabled = true;
            }
        }
    }

    clearValidation() {
        const invalidInputs = document.querySelectorAll(".is-invalid");
        invalidInputs.forEach(input => {
            input.classList.remove("is-invalid");
        });
        this.hideAlert();
    }

    setFieldInvalid(inputId, messageId, message) {
        const input = document.getElementById(inputId);
        const feedback = document.getElementById(messageId);

        if (input) {
            input.classList.add("is-invalid");
        }

        if (feedback) {
            feedback.textContent = message;
        }
    }

    isEmailAllowed(email) {
        if (!email || email.indexOf("@") === -1) {
            return false;
        }

        const lower = email.toLowerCase();
        if (lower.endsWith("@gmail.com")) {
            return true;
        }
        if (lower.endsWith("@hotmail.es")) {
            return true;
        }
        return false;
    }

    showAlert(messages) {
        const alertBox = document.getElementById("usersAlert");
        if (!alertBox) {
            return;
        }

        const unique = Array.from(new Set(messages));
        alertBox.innerHTML = "<strong>Revisa los campos:</strong> " + unique.join(" | ");
        alertBox.classList.remove("d-none");
    }

    hideAlert() {
        const alertBox = document.getElementById("usersAlert");
        if (!alertBox) {
            return;
        }
        alertBox.classList.add("d-none");
        alertBox.textContent = "";
    }

    renderNotLogged() {
        const container = document.getElementById("mvc-main");
        container.innerHTML = "<div class='alert alert-warning'>Debes iniciar sesión para ver los usuarios.</div>";
    }

    renderNotAllowed(message) {
        const container = document.getElementById("mvc-main");
        container.innerHTML = "<div class='alert alert-danger'>" + message + "</div>";
    }

}
