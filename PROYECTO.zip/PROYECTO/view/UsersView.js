import User from "../model/User.js";

export default class UsersView {
    constructor() {
        this.plantillaList = null;
        this.plantillaForm = null;
    }

    /* ===================== CARGA TEMPLATES ===================== */

    async loadListTemplate() {
        if (!this.plantillaList) {
            const response = await fetch("./html/users.html");
            this.plantillaList = await response.text();
        }
    }

    async loadFormTemplate() {
        if (!this.plantillaForm) {
            const response = await fetch("./html/user.html");
            this.plantillaForm = await response.text();
        }
    }

    /* ===================== RENDER LIST ===================== */

    async renderList(users) {
        await this.loadListTemplate();
        const container = document.getElementById("mvc-main");
        container.innerHTML = this.plantillaList;

        let html = "<table class='tableUsers'>";
        html += "<tr>";
        html += "<th>ID</th><th>Nombre</th><th>Email</th><th>Rol</th><th>Activo</th><th>Acciones</th>";
        html += "</tr>";

       users.forEach(user => {
            html += "<tr>";
            html += "<td>" + user.id + "</td>";
            html += "<td>" + user.nombre + "</td>";
            html += "<td>" + user.email + "</td>";
            html += "<td>" + user.rol + "</td>";

            // Mostrar Sí o No según activo
            if (user.activo == 1) {
                html += "<td>Sí</td>";
            } else {
                html += "<td>No</td>";
            }

            html += "<td>";

            // Botón Editar siempre
            html += "<button class='mvc-clickable' name='editarUser' data-mvcid='" + user.id + "'>Editar</button>";

            // Botón Activar/Desactivar según estado
            if (user.activo == 1) {
            html += "<button class='mvc-clickable' name='deactivateUser' data-mvcid='" + user.id + "'>Desactivar</button>";
            } else {
            html += "<button class='mvc-clickable' name='activateUser' data-mvcid='" + user.id + "'>Activar</button>";
            }

            html += "</td>";
            html += "</tr>";
});

        html += "</table>";

        container.innerHTML += html;

        // Botón crear nuevo usuario
        const btnCrear = document.createElement("button");
        btnCrear.textContent = "Crear Nuevo Usuario";
        btnCrear.classList.add("mvc-clickable");
        btnCrear.setAttribute("name", "crearUser");
        container.appendChild(btnCrear);
    }

    /* ===================== RENDER CREATE ===================== */

    async renderForm(user) {
    await this.loadFormTemplate();

    const container = document.getElementById("mvc-main");
    container.innerHTML = this.plantillaForm;

    // Si user existe, estamos editando
    if (user) {
        document.getElementById("usersTitle").textContent = "Editar usuario";
        document.getElementById("saveUser").name = "updateUser";

        document.getElementById("id").value = user.id;
        document.getElementById("nombre").value = user.nombre;
        document.getElementById("email").value = user.email;
        document.getElementById("rol").value = user.rol;
        document.getElementById("activo").value = user.activo;
    } else {
        // Nuevo usuario
        document.getElementById("usersTitle").textContent = "Nuevo usuario";
        document.getElementById("saveUser").name = "insertUser";

        document.getElementById("id").value = "";
        document.getElementById("nombre").value = "";
        document.getElementById("email").value = "";
        document.getElementById("rol").value = "cliente";
        document.getElementById("activo").value = 1;
    }

    // Campos comunes
    document.getElementById("id").disabled = true;
    document.getElementById("password").value = ""; // Nunca rellenamos contraseña
}


    // Para compatibilidad con tu código anterior
    async renderCreate() {
        return this.renderForm(null);
    }

    async renderEdit(user) {
        return this.renderForm(user);
    }

    /* ===================== GETTERS ===================== */

    getFormData() {
        const user = new User();
        user.id = document.getElementById("id").value;
        user.nombre = document.getElementById("nombre").value;
        user.email = document.getElementById("email").value;
        user.password = document.getElementById("password").value;
        user.rol = document.getElementById("rol").value;
        user.activo = Number(document.getElementById("activo").value);
        return user;
    }

    getTextSearch() {
    const input = document.getElementById("txtNameSearch");

    if (input !== null) {
        return input.value;
    }

    return "";
}

}

