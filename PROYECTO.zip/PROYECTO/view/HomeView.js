export default class HomeView {
    constructor() {
        this.plantilla = null;
    }

    async loadTemplate() {
        if (!this.plantilla) {
            const response = await fetch("./html/home.html");
            this.plantilla = await response.text();
        }
    }

    async render(textParams = {}) {
        try {
            await this.loadTemplate();

            // Simple reemplazo manual de parámetros {{SALUDO}} y {{FOOTER}}
            let html = this.plantilla;
            for (const key in textParams) {
                html = html.replace(new RegExp(`{{${key}}}`, "g"), textParams[key]);
            }

            document.getElementById("mvc-main").innerHTML = html;

        } catch (err) {
            document.getElementById("mvc-main").textContent = "Something went wrong...";
            console.error(err);
        }
    }
}


