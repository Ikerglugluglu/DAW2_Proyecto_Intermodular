// AuthView: render y validaciones de login, registro y configuracion
export default class AuthView {
    constructor() {
        this.loginTemplate = null;
        this.registerTemplate = null;
    }

    // ---------- Carga de templates ----------

    async loadLoginTemplate() {
        if (!this.loginTemplate) {
            const response = await fetch("./html/login.html");
            this.loginTemplate = await response.text();
        }
    }

    async loadRegisterTemplate() {
        if (!this.registerTemplate) {
            const response = await fetch("./html/register.html");
            this.registerTemplate = await response.text();
        }
    }

    // ---------- Render ----------

    async renderLogin() {
        await this.loadLoginTemplate();
        const container = document.getElementById("mvc-main");
        container.innerHTML = this.loginTemplate;
    }

    async renderRegister() {
        await this.loadRegisterTemplate();
        const container = document.getElementById("mvc-main");
        container.innerHTML = this.registerTemplate;
    }

    async renderConfig(user) {
        if (!this.configTemplate) {
            const response = await fetch("./html/config.html");
            this.configTemplate = await response.text();
        }

        const container = document.getElementById("mvc-main");
        container.innerHTML = this.configTemplate;

        const nombreInput = document.getElementById("configNombre");
        const emailInput = document.getElementById("configEmail");

        if (nombreInput && user && user.nombre) {
            nombreInput.value = user.nombre;
        }

        if (emailInput && user && user.email) {
            emailInput.value = user.email;
        }

        const changePassword = document.getElementById("configChangePassword");
        const passwordInput = document.getElementById("configPassword");
        const confirmInput = document.getElementById("configPasswordConfirm");
        if (changePassword && passwordInput) {
            changePassword.checked = false;
            passwordInput.value = "";
            passwordInput.disabled = true;
            if (confirmInput) {
                confirmInput.value = "";
                confirmInput.disabled = true;
            }

            changePassword.addEventListener("change", () => {
                if (changePassword.checked) {
                    passwordInput.disabled = false;
                    if (confirmInput) {
                        confirmInput.disabled = false;
                    }
                } else {
                    passwordInput.value = "";
                    passwordInput.disabled = true;
                    if (confirmInput) {
                        confirmInput.value = "";
                        confirmInput.disabled = true;
                    }
                }
            });
        }
    }

    async renderUserInfo(user) {
        if (!this.userInfoTemplate) {
            const response = await fetch("./html/userinfo.html");
            this.userInfoTemplate = await response.text();
        }

        const container = document.getElementById("mvc-main");
        container.innerHTML = this.userInfoTemplate;

        const nameEl = document.getElementById("infoNombre");
        const emailEl = document.getElementById("infoEmail");

        if (nameEl) {
            nameEl.textContent = user.nombre || "";
        }
        if (emailEl) {
            emailEl.textContent = user.email || "";
        }
       
    }

    // ---------- Helpers de validacion ----------

    clearValidation(formId) {
        const form = document.getElementById(formId);
        if (!form) {
            return;
        }

        const invalidInputs = form.querySelectorAll(".is-invalid");
        invalidInputs.forEach(input => {
            input.classList.remove("is-invalid");
        });
    }

    setFieldInvalid(inputId, messageId, message) {
        const input = document.getElementById(inputId);
        const feedback = document.getElementById(messageId);

        if (input) {
            input.classList.add("is-invalid");
        }

        if (feedback) {
            feedback.textContent = message;
        }
    }

    isEmailAllowed(email) {
        if (email.indexOf("@") === -1) {
            return false;
        }

        const lower = email.toLowerCase();
        if (lower.endsWith("@gmail.com")) {
            return true;
        }

        if (lower.endsWith("@hotmail.es")) {
            return true;
        }

        return false;
    }


    // ---------- Obtencion de datos ----------

    getLoginData(payload) {
        if (payload && payload.email && payload.password) {
            return {
                email: payload.email,
                password: payload.password
            };
        }

        this.clearValidation("loginForm");

        const emailInput = document.getElementById("loginEmail");
        const passwordInput = document.getElementById("loginPassword");

        if (!emailInput || !passwordInput) {
            return null;
        }

        const email = emailInput.value.trim();
        const password = passwordInput.value;

        let hasErrors = false;

        if (email === "") {
            this.setFieldInvalid("loginEmail", "loginEmailError", "El email es obligatorio");
            hasErrors = true;
        }

        if (email !== "" && !this.isEmailAllowed(email)) {
            this.setFieldInvalid(
                "loginEmail",
                "loginEmailError",
                "El email debe ser @gmail.com o @hotmail.es"
            );
            hasErrors = true;
        }

        if (password === "") {
            this.setFieldInvalid("loginPassword", "loginPasswordError", "La contraseña es obligatoria");
            hasErrors = true;
        }

        if (hasErrors) {
            return null;
        }

        return { email, password };
    }

    getRegisterData(payload) {
        if (payload && payload.nombre && payload.email && payload.password) {
            return {
                nombre: payload.nombre,
                email: payload.email,
                password: payload.password,
                rol: payload.rol || "cliente"
            };
        }

        this.clearValidation("registerForm");

        const nombreInput = document.getElementById("registerNombre");
        const emailInput = document.getElementById("registerEmail");
        const passwordInput = document.getElementById("registerPassword");

        if (!nombreInput || !emailInput || !passwordInput) {
            return null;
        }

        const nombre = nombreInput.value.trim();
        const email = emailInput.value.trim();
        const password = passwordInput.value;

        let hasErrors = false;

        if (nombre === "") {
            this.setFieldInvalid("registerNombre", "registerNombreError", "El nombre es obligatorio");
            hasErrors = true;
        }

        if (email === "") {
            this.setFieldInvalid("registerEmail", "registerEmailError", "El email es obligatorio");
            hasErrors = true;
        }

        if (email !== "" && !this.isEmailAllowed(email)) {
            this.setFieldInvalid(
                "registerEmail",
                "registerEmailError",
                "El email debe ser @gmail.com o @hotmail.es"
            );
            hasErrors = true;
        }

        if (password === "") {
            this.setFieldInvalid("registerPassword", "registerPasswordError", "La contraseña es obligatoria");
            hasErrors = true;
        }

        if (hasErrors) {
            return null;
        }

        // Rol fijo en cliente, no se permite elegir en registro
        const rol = "cliente";

        return { nombre, email, password, rol };
    }

    getConfigData(user) {
        this.clearValidation("configForm");

        const nombreInput = document.getElementById("configNombre");
        const emailInput = document.getElementById("configEmail");
        const passwordInput = document.getElementById("configPassword");
        const confirmInput = document.getElementById("configPasswordConfirm");
        const changePassword = document.getElementById("configChangePassword");

        if (!nombreInput || !emailInput || !passwordInput || !confirmInput || !changePassword) {
            return null;
        }

        const nombre = nombreInput.value.trim();
        const email = emailInput.value.trim();
        const password = passwordInput.value;
        const passwordConfirm = confirmInput.value;

        let hasErrors = false;

        if (nombre === "") {
            this.setFieldInvalid("configNombre", "configNombreError", "El nombre es obligatorio");
            hasErrors = true;
        }

        if (email === "") {
            this.setFieldInvalid("configEmail", "configEmailError", "El email es obligatorio");
            hasErrors = true;
        }

        if (email !== "" && !this.isEmailAllowed(email)) {
            this.setFieldInvalid(
                "configEmail",
                "configEmailError",
                "El email debe ser @gmail.com o @hotmail.es"
            );
            hasErrors = true;
        }

        if (changePassword.checked) {
            if (password === "") {
                this.setFieldInvalid("configPassword", "configPasswordError", "La contraseña es obligatoria");
                hasErrors = true;
            }
            if (passwordConfirm === "") {
                this.setFieldInvalid("configPasswordConfirm", "configPasswordConfirmError", "Repite la contraseña");
                hasErrors = true;
            }
            if (password !== "" && passwordConfirm !== "" && password !== passwordConfirm) {
                this.setFieldInvalid("configPasswordConfirm", "configPasswordConfirmError", "Las contraseñas no coinciden");
                hasErrors = true;
            }
        }

        if (hasErrors) {
            return null;
        }

        const result = {
            id: user.id,
            nombre,
            email
        };

        if (changePassword.checked) {
            result.password = password;
        }

        return result;
    }

    // ---------- Mensajes ----------

    showError(message) {
        this.showAlert(message, "danger");
    }

    showAlert(message, type) {
        const alertBox = document.getElementById("authAlert");
        if (!alertBox) {
            console.log("AuthView alert:", message);
            return;
        }

        alertBox.className = "alert alert-" + type;
        alertBox.textContent = message;
        alertBox.classList.remove("d-none");
    }

    onLoginSuccess(data) {
        this.showAlert("Login correcto", "success");
        console.log("Login correcto:", data);
    }

    onLoginError(message) {
        this.showAlert(message, "danger");
        console.log("Login error:", message);
    }

    onRegisterSuccess(data) {
        this.showAlert("Registro correcto", "success");
        console.log("Registro correcto:", data);
    }

    onRegisterError(message) {
        this.showAlert(message, "danger");
        console.log("Registro error:", message);
    }

    onLogoutSuccess(data) {
        this.showAlert("Sesion cerrada", "success");
        console.log("Logout correcto:", data);
    }

    onLogoutError(message) {
        this.showAlert(message, "danger");
        console.log("Logout error:", message);
    }

    onMeResult(data) {
        console.log("Sesion actual:", data);
    }

    onMeError(message) {
        console.log("Sesion error:", message);
    }

    onCheckAdmin(ok) {
        console.log("Check admin:", ok);
    }

    onCheckEmpleado(ok) {
        console.log("Check empleado:", ok);
    }

    onProfileSuccess(data) {
        this.showAlert("Perfil actualizado", "success");
        console.log("Perfil actualizado:", data);
    }

    onProfileError(message) {
        this.showAlert(message, "danger");
        console.log("Perfil error:", message);
    }

}
