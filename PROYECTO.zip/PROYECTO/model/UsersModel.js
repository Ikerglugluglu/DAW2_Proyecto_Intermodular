import { urlAPIUsers } from './apiConfig.js';

export default class UsersModel {
    constructor(apiUrl = urlAPIUsers) {
        this.apiUrl = apiUrl;
    }

    async getAll() {
        try {
            const response = await fetch(this.apiUrl);
            if (!response.ok) {
                const errorObject = await response.json();
                console.log(errorObject.error);
                return;
            }
            return await response.json();
        } catch (error) {
            console.log("Error de conexión o JSON en getAll:", error);
        }
    }

    async getById(id) {
        try {
            const response = await fetch(`${this.apiUrl}?id=${id}`);
            if (!response.ok) {
                const errorObject = await response.json();
                console.log(errorObject.error);
                return;
            }
            return await response.json();
        } catch (error) {
            console.log("Error de conexión o JSON en getById:", error);
        }
    }

    async getByName(nombre) {
        try {
            const response = await fetch(`${this.apiUrl}?name=${encodeURIComponent(nombre)}`);
            if (!response.ok) {
                const errorObject = await response.json();
                console.log(errorObject.error);
                return;
            }
            return await response.json();
        } catch (error) {
            console.log("Error de conexión o JSON en getByName:", error);
        }
    }

    async insertUser(user) {
        try {
            console.log("ROL ENVIADO 👉", JSON.stringify(user.rol));
            const response = await fetch(this.apiUrl, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(user)
            });
            if (!response.ok) {
                const errorObject = await response.json();
                console.log(errorObject.error);
                return;
            }
            return await response.json();
        } catch (error) {
            console.log("Error de conexión o JSON en insertUser:", error);
        }
    }

    async updateUser(user) {
        try {
            console.log("ROL ENVIADO 👉", JSON.stringify(user.rol));
            const response = await fetch(this.apiUrl, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(user)
            });
            if (!response.ok) {
                const errorObject = await response.json();
                console.log(errorObject.error);
                return;
            }
            return await response.json();
        } catch (error) {
            console.log("Error de conexión o JSON en updateUser:", error);
        }
    }

    async deactivateUser(id) {
        try {
            const response = await fetch(this.apiUrl, {
                method: "DELETE",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ id })
            });
            if (!response.ok) {
                const errorObject = await response.json();
                console.log(errorObject.error);
                return;
            }
            return await response.json();
        } catch (error) {
            console.log("Error de conexión o JSON en deactivateUser:", error);
        }
    }
   async activateUser(id) {
    try {
        // Obtener el usuario completo
        const user = await this.getById(id);
        if (!user) {
            console.log("Usuario no encontrado");
            return;
        }

        // Cambiar activo a 1
        user.activo = 1;

        // Llamar a la API PUT
        const response = await fetch(this.apiUrl, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                id: user.id,
                nombre: user.nombre,
                email: user.email,
                rol: user.rol,
                activo: user.activo
            })
        });

        if (!response.ok) {
            const errorObject = await response.json();
            console.log(errorObject.error);
            return;
        }

        return await response.json();
    } catch (error) {
        console.log("Error en activateUser:", error);
    }
}

}




