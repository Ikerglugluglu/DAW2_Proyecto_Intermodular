// UsersModel: acceso a la API de usuarios
import { urlAPIUsers } from './apiConfig.js';

export default class UsersModel {
    constructor(apiUrl = urlAPIUsers) {
        this.apiUrl = apiUrl;
    }

    async getAll() {
        try {
            const response = await fetch(this.apiUrl, {
                credentials: "include"
            });
            if (!response.ok) {
                const errorObject = await response.json();
                console.log(errorObject.error);
                return;
            }
            return await response.json();
        } catch (error) {
            console.log("Error de conexión o JSON en getAll:", error);
        }
    }

    async getById(id) {
        try {
            const response = await fetch(`${this.apiUrl}?id=${id}`, {
                credentials: "include"
            });
            if (!response.ok) {
                const errorObject = await response.json();
                console.log(errorObject.error);
                return;
            }
            const data = await response.json();
            if (Array.isArray(data)) {
                return data.find(u => Number(u.id) === Number(id)) || null;
            }
            return data;
        } catch (error) {
            console.log("Error de conexión o JSON en getById:", error);
        }
    }

    async getByName(nombre) {
        try {
            const response = await fetch(`${this.apiUrl}?name=${encodeURIComponent(nombre)}`, {
                credentials: "include"
            });
            if (!response.ok) {
                const errorObject = await response.json();
                console.log(errorObject.error);
                return;
            }
            return await response.json();
        } catch (error) {
            console.log("Error de conexión o JSON en getByName:", error);
        }
    }

    async insertUser(user) {
        try {
            console.log("ROL ENVIADO 👉", JSON.stringify(user.rol));
            const response = await fetch(this.apiUrl, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                credentials: "include",
                body: JSON.stringify(user)
            });
            if (!response.ok) {
                const errorObject = await response.json();
                console.log(errorObject.error);
                return;
            }
            return await response.json();
        } catch (error) {
            console.log("Error de conexión o JSON en insertUser:", error);
        }
    }

    async updateUser(user) {
        try {
            console.log("ROL ENVIADO 👉", JSON.stringify(user.rol));
            const response = await fetch(this.apiUrl, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                credentials: "include",
                body: JSON.stringify(user)
            });
            if (!response.ok) {
                const errorObject = await response.json();
                console.log(errorObject.error);
                return;
            }
            return await response.json();
        } catch (error) {
            console.log("Error de conexión o JSON en updateUser:", error);
        }
    }

    async updateSelf(data) {
        try {
            const response = await fetch(this.apiUrl, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                credentials: "include",
                body: JSON.stringify(data)
            });
            if (!response.ok) {
                const errorObject = await response.json();
                if (errorObject && errorObject.error) {
                    return { error: errorObject.error };
                }
                return { error: "No se pudo actualizar" };
            }
            return await response.json();
        } catch (error) {
            console.log("Error de conexión o JSON en updateSelf:", error);
            return { error: "No se pudo actualizar" };
        }
    }

    async deactivateUser(id) {
        try {
            const response = await fetch(this.apiUrl, {
                method: "DELETE",
                headers: { "Content-Type": "application/json" },
                credentials: "include",
                body: JSON.stringify({ id })
            });
            if (!response.ok) {
                const errorObject = await response.json();
                console.log(errorObject.error);
                return;
            }
            return await response.json();
        } catch (error) {
            console.log("Error de conexión o JSON en deactivateUser:", error);
        }
    }
   async activateUser(id) {
    try {
        // Obtener el usuario completo
        const user = await this.getById(id);
        if (!user) {
            console.log("Usuario no encontrado");
            return;
        }

        // Cambiar activo a 1
        user.activo = 1;

        // Llamar a la API PUT
        const response = await fetch(this.apiUrl, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            credentials: "include",
            body: JSON.stringify({
                id: user.id,
                nombre: user.nombre,
                email: user.email,
                rol: user.rol,
                activo: user.activo
            })
        });

        if (!response.ok) {
            const errorObject = await response.json();
            console.log(errorObject.error);
            return;
        }

        return await response.json();
    } catch (error) {
        console.log("Error en activateUser:", error);
    }
}

}
