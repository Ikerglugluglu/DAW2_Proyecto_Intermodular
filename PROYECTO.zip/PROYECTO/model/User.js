export default class User {
    constructor(id, nombre, email, password, rol, activo, creado_en) {
        this.id = id;
        this.nombre = nombre;
        this.email = email;
        this.password = password;
        this.rol = rol;
        this.activo = activo;
        this.creado_en = creado_en;
    }
}
