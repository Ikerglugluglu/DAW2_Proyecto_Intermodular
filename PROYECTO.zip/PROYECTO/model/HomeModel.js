export default class HomeModel {

  getHomeText() {
    return "Bienvenido al proyecto intermodular";
  }
}
