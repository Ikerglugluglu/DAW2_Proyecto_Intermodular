// AuthModel: capa de acceso a la API de autenticacion
import { urlAPIAuth } from './apiConfig.js';

export default class AuthModel {
    constructor(apiUrl = urlAPIAuth) {
        this.apiUrl = apiUrl;
    }

    // ---------- Helpers ----------

    async parseJsonSafe(response) {
        try {
            return await response.json();
        } catch (error) {
            return null;
        }
    }

    // ---------- Auth endpoints ----------

    async login(email, password) {
        try {
            const response = await fetch(`${this.apiUrl}/login.php`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                credentials: "include",
                body: JSON.stringify({ email, password })
            });

            const data = await this.parseJsonSafe(response);

            if (!response.ok) {
                if (data && data.error) {
                    console.log(data.error);
                    return { error: data.error };
                }
                return { error: "No se pudo iniciar sesion" };
            }

            return data;
        } catch (error) {
            console.log("Error de conexión o JSON en login:", error);
            return { error: "No se pudo iniciar sesion" };
        }
    }

    async register(nombre, email, password, rol = "cliente") {
        try {
            const response = await fetch(`${this.apiUrl}/register.php`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                credentials: "include",
                body: JSON.stringify({ nombre, email, password, rol })
            });

            const data = await this.parseJsonSafe(response);

            if (!response.ok) {
                if (data && data.error) {
                    console.log(data.error);
                    return { error: data.error };
                }
                return { error: "No se pudo registrar" };
            }

            return data;
        } catch (error) {
            console.log("Error de conexión o JSON en register:", error);
            return { error: "No se pudo registrar" };
        }
    }

    async logout() {
        try {
            const response = await fetch(`${this.apiUrl}/logout.php`, {
                method: "POST",
                credentials: "include"
            });

            const data = await this.parseJsonSafe(response);

            if (!response.ok) {
                if (data && data.error) {
                    console.log(data.error);
                }
                return null;
            }

            return data;
        } catch (error) {
            console.log("Error de conexión o JSON en logout:", error);
            return null;
        }
    }

    async me() {
        try {
            const response = await fetch(`${this.apiUrl}/me.php`, {
                method: "GET",
                credentials: "include"
            });

            const data = await this.parseJsonSafe(response);

            if (!response.ok) {
                if (data && data.error) {
                    console.log(data.error);
                }
                return null;
            }

            return data;
        } catch (error) {
            console.log("Error de conexión o JSON en me:", error);
            return null;
        }
    }

    async checkAdmin() {
        try {
            const response = await fetch(`${this.apiUrl}/checkAdmin.php`, {
                method: "GET",
                credentials: "include"
            });

            if (!response.ok) {
                return false;
            }

            return true;
        } catch (error) {
            console.log("Error de conexión en checkAdmin:", error);
            return false;
        }
    }

    async checkEmpleado() {
        try {
            const response = await fetch(`${this.apiUrl}/checkEmpleado.php`, {
                method: "GET",
                credentials: "include"
            });

            if (!response.ok) {
                return false;
            }

            return true;
        } catch (error) {
            console.log("Error de conexión en checkEmpleado:", error);
            return false;
        }
    }
}
