// apiConfig: URLs base de la API
const urlAPIUsers = "http://localhost/PROYECTO/api/users.php";
const urlAPIProducts = "http://localhost/PROYECTO/api/productes.php";
const urlAPIOrders = "http://localhost/PROYECTO/api/orders.php";
const urlAPIAuth = "http://localhost/PROYECTO/api/auth";

export { urlAPIUsers, urlAPIProducts, urlAPIOrders, urlAPIAuth };
