<?php

include '../control/roles.php';

// Solo accesible a admin
checkRole('empleado');

echo "Bienvenido al panel de empleado, " . $_SESSION['nombre'];
?>
<form action="/PROYECTO/auth/go_index.php" method="post">
    <button type="submit">Inicio</button>
</form>
