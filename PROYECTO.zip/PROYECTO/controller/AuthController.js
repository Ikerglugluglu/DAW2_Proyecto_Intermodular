// AuthController: orquesta autenticacion y vistas relacionadas
import AuthModel from "../model/AuthModel.js";
import AuthView from "../view/AuthView.js";
import UsersModel from "../model/UsersModel.js";

export default class AuthController {
    constructor() {
        this.model = new AuthModel();
        this.view = new AuthView();
        this.usersModel = new UsersModel();
    }

    async doAction(action, payload = null) {
        switch (action) {
            case "showLogin": {
                await this.view.renderLogin();
                return null;
            }

            case "showRegister": {
                await this.view.renderRegister();
                return null;
            }

            case "showConfig": {
                const session = await this.model.me();
                if (!session || !session.logged || !session.user) {
                    this.view.showError("Debes iniciar sesión para configurar tu cuenta");
                    return null;
                }
                await this.view.renderConfig(session.user);
                return null;
            }

            case "showUserInfo": {
                const session = await this.model.me();
                if (!session || !session.logged || !session.user) {
                    this.view.showError("Debes iniciar sesión para ver tu información");
                    return null;
                }
                await this.view.renderUserInfo(session.user);
                return null;
            }

            case "login": {
                // Si no hay vista todavia, se puede pasar payload con email/password
                const data = this.view.getLoginData(payload);
                if (!data) {
                    this.view.showError("Faltan datos para login");
                    return null;
                }

                const result = await this.model.login(data.email, data.password);
                if (result && !result.error) {
                    this.view.onLoginSuccess(result);
                } else {
                    let message = "No se pudo iniciar sesion";
                    if (result && result.error) {
                        message = result.error;
                    }
                    this.view.onLoginError(message);
                }
                return result;
            }

            case "register": {
                // Si no hay vista todavia, se puede pasar payload con nombre/email/password/rol
                const data = this.view.getRegisterData(payload);
                if (!data) {
                    this.view.showError("Faltan datos para registro");
                    return null;
                }

                const result = await this.model.register(
                    data.nombre,
                    data.email,
                    data.password,
                    data.rol
                );
                if (result && !result.error) {
                    this.view.onRegisterSuccess(result);
                } else {
                    let message = "No se pudo registrar";
                    if (result && result.error) {
                        message = result.error;
                    }
                    this.view.onRegisterError(message);
                }
                return result;
            }

            case "updateProfile": {
                const session = await this.model.me();
                if (!session || !session.logged || !session.user) {
                    this.view.showError("Debes iniciar sesión para configurar tu cuenta");
                    return null;
                }

                const data = this.view.getConfigData(session.user);
                if (!data) {
                    this.view.showError("Faltan datos para actualizar");
                    return null;
                }

                const result = await this.usersModel.updateSelf(data);
                if (result && !result.error) {
                    this.view.onProfileSuccess(result);
                    // Refrescar datos de sesión en el header
                    await this.view.updateHeader(this.model);

                    // Volver a cargar el formulario con datos actualizados
                    if (result && result.nombre && result.email) {
                        await this.view.renderConfig(result);
                    } else {
                        const refreshed = await this.model.me();
                        if (refreshed && refreshed.logged && refreshed.user) {
                            await this.view.renderConfig(refreshed.user);
                        }
                    }
                } else {
                    let message = "No se pudo actualizar";
                    if (result && result.error) {
                        message = result.error;
                    }
                    this.view.onProfileError(message);
                }
                return result;
            }

            case "logout": {
                const result = await this.model.logout();
                if (result) {
                    this.view.onLogoutSuccess(result);
                } else {
                    this.view.onLogoutError("No se pudo cerrar sesion");
                }
                return result;
            }

            case "getSession": {
                return await this.model.me();
            }

            case "me": {
                const result = await this.model.me();
                if (result) {
                    this.view.onMeResult(result);
                } else {
                    this.view.onMeError("No se pudo obtener la sesion");
                }
                return result;
            }

            case "checkAdmin": {
                const ok = await this.model.checkAdmin();
                this.view.onCheckAdmin(ok);
                return ok;
            }

            case "checkEmpleado": {
                const ok = await this.model.checkEmpleado();
                this.view.onCheckEmpleado(ok);
                return ok;
            }

            default:
                console.error("AuthController: accion no reconocida:", action);
                return null;
        }
    }
}
