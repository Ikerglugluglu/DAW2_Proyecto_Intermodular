import HomeController from "./HomeController.js";
import UsersController from "./UsersController.js";

export default class MainController {

  constructor() {
    this.myHomeController = new HomeController();
    this.myUsersController = new UsersController();
  }

 async doAction(action, id = null) {

    switch (action) {

      case "home":
        this.myHomeController.doAction("getHome");
        break;

      case "users":
        this.myUsersController.doAction("getAll");
        break;

      case "crearUser":
        this.myUsersController.doAction("crearUser");
        break;
      case "getByNameUser":
        this.myUsersController.doAction("getByName")
      
        break;
      case "insertUser":
        this.myUsersController.doAction("insertUser");
        break;

      case "editarUser":
        this.myUsersController.doAction("editarUser", id);
        break;

      case "updateUser":
        this.myUsersController.doAction("updateUser");
        break;
      case "deactivateUser": 
        console.log("inicia desactivar " + id);
        const resultDesactivar = await this.myUsersController.doAction("deactivateUser", id);
        console.log("después de controller deactivateUser " + id);
        if (resultDesactivar) {
          await this.myUsersController.doAction("getAll");
        }
        break;

      case "activateUser": 
        console.log("inicia activar " + id);
        const resultActivar = await this.myUsersController.doAction("activateUser", id);
        console.log("después de controller activateUser", resultActivar);
        break; // getAll ya se llama dentro de UsersController
      
      default:
        console.warn("MainController: acción no reconocida:", action);
        break;
    }
  }
}
