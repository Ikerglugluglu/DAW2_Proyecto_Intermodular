// MainController: enrutador principal de acciones MVC
import HomeController from "./HomeController.js";
import UsersController from "./UsersController.js";
import AuthController from "./AuthController.js";
import HeaderView from "../view/HeaderView.js";

export default class MainController {

  constructor() {
    this.myHomeController = new HomeController();
    this.myUsersController = new UsersController();
    this.myAuthController = new AuthController();
    this.headerView = new HeaderView();
  }

 async doAction(action, id = null) {

    switch (action) {

      case "home":
        this.myHomeController.doAction("getHome");
        break;

      case "users":
        this.myUsersController.doAction("getAll");
        break;
      
      case "getAll":
        this.myUsersController.doAction("getAll");
        break;

      case "crearUser":
        this.myUsersController.doAction("crearUser");
        break;
      case "getByNameUser":
        this.myUsersController.doAction("getByName")
      
        break;
      
      case "usersPage":
        this.myUsersController.doAction("usersPage", id);
        break;
      case "insertUser":
        this.myUsersController.doAction("insertUser");
        break;

      case "editarUser":
        this.myUsersController.doAction("editarUser", id);
        break;

      case "updateUser":
        this.myUsersController.doAction("updateUser");
        break;
      case "deactivateUser": 
        console.log("inicia desactivar " + id);
        const resultDesactivar = await this.myUsersController.doAction("deactivateUser", id);
        console.log("después de controller deactivateUser " + id);
        if (resultDesactivar) {
          await this.myUsersController.doAction("getAll");
        }
        break;

      case "activateUser": 
        console.log("inicia activar " + id);
        const resultActivar = await this.myUsersController.doAction("activateUser", id);
        console.log("después de controller activateUser", resultActivar);
        break; // getAll ya se llama dentro de UsersController

      case "showLogin":
        await this.myAuthController.doAction("showLogin");
        break;

      case "showRegister":
        await this.myAuthController.doAction("showRegister");
        break;

      case "showConfig":
        await this.myAuthController.doAction("showConfig");
        break;

      case "showUserInfo":
        await this.myAuthController.doAction("showUserInfo");
        break;

      case "login":
        const loginResult = await this.myAuthController.doAction("login");
        if (loginResult && !loginResult.error) {
          this.myHomeController.doAction("getHome");
        }
        await this.refreshAuthUI();
        break;

      case "register":
        const registerResult = await this.myAuthController.doAction("register");
        if (registerResult && !registerResult.error) {
          this.myHomeController.doAction("getHome");
        }
        await this.refreshAuthUI();
        break;

      case "updateProfile":
        await this.myAuthController.doAction("updateProfile");
        break;

      case "refreshAuthUI":
        await this.refreshAuthUI();
        break;

      case "logout":
        await this.myAuthController.doAction("logout");
        await this.refreshAuthUI();
        this.myHomeController.doAction("getHome");
        break;

      case "me":
        await this.myAuthController.doAction("me");
        break;

      case "checkAdmin":
        await this.myAuthController.doAction("checkAdmin");
        break;

      case "checkEmpleado":
        await this.myAuthController.doAction("checkEmpleado");
        break;
      
      default:
        console.warn("MainController: acción no reconocida:", action);
        break;
    }
  }

  async refreshAuthUI() {
    const session = await this.myAuthController.doAction("getSession");
    this.headerView.update(session);
  }
}
