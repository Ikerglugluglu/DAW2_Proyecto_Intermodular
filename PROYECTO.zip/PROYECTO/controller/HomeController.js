import HomeView from "../view/HomeView.js";
import HomeModel from "../model/HomeModel.js";

export default class HomeController {

  constructor() {
    this.model = new HomeModel();
    this.view = new HomeView();
  }

  doAction(action) {
    switch (action) {

      case "getHome":
        const text = this.model.getHomeText();
        this.view.render(text);
        break;

      default:
        console.error("HomeController: acción no reconocida:", action);
        break;
    }
  }
}
