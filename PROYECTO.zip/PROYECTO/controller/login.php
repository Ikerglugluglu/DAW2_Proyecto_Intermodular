<?php
session_start();
header('Content-Type: application/json');

require_once __DIR__ . '/../api/db/DbUsers.php';

try {
    $db = new DbUsers();
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Error al conectar con la base de datos']);
    exit;
}

// Leer JSON POST
$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['email'], $data['password'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Faltan campos obligatorios']);
    exit;
}

$email = $data['email'];
$password = $data['password'];

try {
    $user = $db->getByEmail($email);

    if (!$user['activo']) {
        http_response_code(403);
        echo json_encode(['error' => 'Usuario desactivado']);
        exit;
    }

    // Verificar contraseña
    if (!password_verify($password, $user['password'])) {
        http_response_code(401);
        echo json_encode(['error' => 'Credenciales incorrectas']);
        exit;
    }

    // Todo correcto → iniciar sesión
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_name'] = $user['nombre'];
    $_SESSION['user_rol'] = $user['rol'];

    // Cookie opcional (ejemplo: 1 hora)
    setcookie('user_id', $user['id'], time() + 3600, '/', '', false, true);

    echo json_encode(['mensaje' => 'Login correcto', 'user' => [
        'id' => $user['id'],
        'nombre' => $user['nombre'],
        'rol' => $user['rol']
    ]]);

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['error' => $e->getMessage()]);
}
