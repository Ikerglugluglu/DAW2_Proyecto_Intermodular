import UsersModel from "../model/UsersModel.js";
import UsersView from "../view/UsersView.js";

export default class UsersController {
    constructor() {
        this.model = new UsersModel();
        this.view = new UsersView();
    }

    async doAction(action, id = null) {
        switch (action) {

            case "getAll": {
                const users = await this.model.getAll();
                this.view.renderList(users);
                break;
            }

            case "getByName": {
                console.log("getByName")
                const nameSearch = await this.view.getTextSearch();
                console.log(nameSearch)
                const users = await this.model.getByName(nameSearch);
                this.view.renderList(users);
                break;
            }

            case "crearUser":
                this.view.renderForm();
                break;

            case "insertUser": {
                const user = this.view.getFormData();
                const result = await this.model.insertUser(user);
                if (result) {
                    this.doAction("getAll");
                }
                break;
            }

            case "editarUser": {
                const user = await this.model.getById(id);
                this.view.renderForm(user);
                break;
            }

            case "updateUser": {
                const user = this.view.getFormData();
                const result = await this.model.updateUser(user);
                if (result) {
                    this.doAction("getAll");
                }
                break;
            }

          case "deactivateUser": {
                console.log("llega a UsersController", id);
                const result = await this.model.deactivateUser(id);
                console.log("resultado de desactivar", result);
                this.doAction("getAll");
                return result; // <- importante
            
            }

         case "activateUser": {
            console.log("llega a UsersController activate", id);
            const result = await this.model.activateUser(id); 
            console.log("resultado activar", result);

            if (result) {
                const users = await this.model.getAll();
                this.view.renderList(users); // actualizar la lista automáticamente
            }

            return result; // <- clave: retorna algo útil al MainController
            }


            default:
                console.error("UsersController: acción no reconocida:", action);
                break;
        }
    }
}
