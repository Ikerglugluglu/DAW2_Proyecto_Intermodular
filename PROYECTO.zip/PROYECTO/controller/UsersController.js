import UsersModel from "../model/UsersModel.js";
import UsersView from "../view/UsersView.js";
import AuthModel from "../model/AuthModel.js";

export default class UsersController {
    constructor() {
        this.model = new UsersModel();
        this.view = new UsersView();
        this.authModel = new AuthModel();
        this.sessionRole = null;
        this.sessionUserId = null;
        this.pageSize = 50;
        this.currentPage = 1;
        this.lastUsers = null;
    }

    async doAction(action, id = null) {
        switch (action) {

            case "getAll": {
                const session = await this.ensureSession();
                if (!session) {
                    this.view.renderNotLogged();
                    break;
                }

                this.currentPage = 1;
                const users = await this.model.getAll();
                this.lastUsers = users;
                this.view.renderList(
                    users,
                    this.sessionRole,
                    this.sessionUserId,
                    this.currentPage,
                    this.pageSize
                );
                break;
            }

            case "getByName": {
                const session = await this.ensureSession();
                if (!session) {
                    this.view.renderNotLogged();
                    break;
                }

                if (this.sessionRole === "cliente") {
                    this.view.renderNotAllowed("No tienes permisos para buscar usuarios");
                    break;
                }

                const nameSearch = await this.view.getTextSearch();
                const users = await this.model.getByName(nameSearch);
                this.currentPage = 1;
                this.lastUsers = users;
                this.view.renderList(
                    users,
                    this.sessionRole,
                    this.sessionUserId,
                    this.currentPage,
                    this.pageSize
                );
                break;
            }

            case "crearUser":
                {
                    const session = await this.ensureSession();
                    if (!session) {
                        this.view.renderNotLogged();
                        break;
                    }

                    if (this.sessionRole !== "admin") {
                        this.view.renderNotAllowed("Solo admin puede crear usuarios");
                        break;
                    }

                    this.view.renderForm(null, this.sessionRole);
                }
                break;

            case "insertUser": {
                const session = await this.ensureSession();
                if (!session) {
                    this.view.renderNotLogged();
                    break;
                }

                if (this.sessionRole !== "admin") {
                    this.view.renderNotAllowed("Solo admin puede crear usuarios");
                    break;
                }

                const user = this.view.getFormData();
                const result = await this.model.insertUser(user);
                if (result) {
                    this.doAction("getAll");
                }
                break;
            }

            case "editarUser": {
                const session = await this.ensureSession();
                if (!session) {
                    this.view.renderNotLogged();
                    break;
                }

                if (this.sessionRole === "cliente") {
                    const requestedId = Number(id);
                    if (requestedId !== this.sessionUserId) {
                        this.view.renderNotAllowed("No puedes editar otros usuarios");
                        break;
                    }
                }

                const user = await this.model.getById(id);
                this.view.renderForm(user, this.sessionRole);
                break;
            }

            case "updateUser": {
                const session = await this.ensureSession();
                if (!session) {
                    this.view.renderNotLogged();
                    break;
                }

                if (this.sessionRole === "cliente") {
                    const formData = this.view.getFormData();
                    if (!formData) {
                        break;
                    }
                    const formId = Number(formData.id);
                    if (formId !== this.sessionUserId) {
                        this.view.renderNotAllowed("No puedes editar otros usuarios");
                        break;
                    }
                    const result = await this.model.updateUser(formData);
                    if (result) {
                        this.doAction("getAll");
                    }
                    break;
                }

                if (this.sessionRole === "empleado") {
                    const formData = this.view.getFormData();
                    if (!formData) {
                        break;
                    }
                    const result = await this.model.updateUser(formData);
                    if (result) {
                        this.doAction("getAll");
                    }
                    break;
                }

                if (this.sessionRole === "admin") {
                    const user = this.view.getFormData();
                    if (!user) {
                        break;
                    }
                    const result = await this.model.updateUser(user);
                    if (result) {
                        this.doAction("getAll");
                    }
                    break;
                }
                break;
            }

          case "deactivateUser": {
                const session = await this.ensureSession();
                if (!session) {
                    this.view.renderNotLogged();
                    return null;
                }

                if (this.sessionRole !== "admin") {
                    this.view.renderNotAllowed("Solo admin puede desactivar usuarios");
                    return null;
                }

                const result = await this.model.deactivateUser(id);
                this.doAction("getAll");
                return result; // <- importante
            
            }

         case "activateUser": {
            const session = await this.ensureSession();
            if (!session) {
                this.view.renderNotLogged();
                return null;
            }

            if (this.sessionRole !== "admin") {
                this.view.renderNotAllowed("Solo admin puede activar usuarios");
                return null;
            }

            const result = await this.model.activateUser(id);

            if (result) {
                const users = await this.model.getAll();
                this.lastUsers = users;
                this.view.renderList(
                    users,
                    this.sessionRole,
                    this.sessionUserId,
                    this.currentPage,
                    this.pageSize
                );
            }

            return result; // <- clave: retorna algo útil al MainController
            }

            case "usersPage": {
                const session = await this.ensureSession();
                if (!session) {
                    this.view.renderNotLogged();
                    break;
                }

                const page = Number(id);
                if (!page || page < 1) {
                    break;
                }
                this.currentPage = page;
                if (this.lastUsers) {
                    this.view.renderList(
                        this.lastUsers,
                        this.sessionRole,
                        this.sessionUserId,
                        this.currentPage,
                        this.pageSize
                    );
                }
                break;
            }


            default:
                console.error("UsersController: acción no reconocida:", action);
                break;
        }
    }

    async ensureSession() {
        const session = await this.authModel.me();

        if (!session || !session.logged || !session.user) {
            this.sessionRole = null;
            this.sessionUserId = null;
            return null;
        }

        this.sessionRole = session.user.rol;
        this.sessionUserId = session.user.id;
        return session;
    }
}
