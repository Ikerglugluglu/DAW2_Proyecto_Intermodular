<?php
session_start();
header('Content-Type: application/json');

require_once __DIR__ . '/../api/db/DbUsers.php';

$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['nombre'], $data['email'], $data['password'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Faltan campos obligatorios']);
    exit;
}

$nombre = $data['nombre'];
$email = $data['email'];
$password = $data['password'];
$rol = $data['rol'] ?? 'cliente'; // por defecto cliente

try {
    $db = new DbUsers();

    // Verificar si el email ya existe
    try {
        $existing = $db->getByEmail($email);
        http_response_code(409);
        echo json_encode(['error' => 'El email ya está registrado']);
        exit;
    } catch (Exception $e) {
        // No existe → seguimos
    }

    // Hashear contraseña
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    $newUser = $db->insert($nombre, $email, $hashedPassword, $rol);

    // Iniciar sesión al registrarse
    $_SESSION['user_id'] = $newUser['id'];
    $_SESSION['user_name'] = $newUser['nombre'];
    $_SESSION['user_rol'] = $newUser['rol'];

    setcookie('user_id', $newUser['id'], time() + 3600, '/', '', false, true);

    echo json_encode(['mensaje' => 'Registro correcto', 'user' => [
        'id' => $newUser['id'],
        'nombre' => $newUser['nombre'],
        'rol' => $newUser['rol']
    ]]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
