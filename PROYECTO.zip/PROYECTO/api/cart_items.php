<?php
header('Content-Type: application/json');
header('Allow: GET, POST, PUT, DELETE');

require 'db/DbCartItems.php';

function getData()
{
    $contentType = $_SERVER['CONTENT_TYPE'] ?? '';

    if (strpos($contentType, 'application/json') !== false) {
        $data = json_decode(file_get_contents('php://input'), true);
    } elseif (strpos($contentType, 'application/x-www-form-urlencoded') !== false) {
        parse_str(file_get_contents('php://input'), $data);
    } else {
        header('HTTP/1.1 400 Bad Request');
        echo json_encode(['error' => 'Unsupported Content-Type']);
        exit;
    }
    return $data;
}

try {
    $db = new DbCartItems();
} catch (Exception $e) {
    header('HTTP/1.1 500 Internal Server Error');
    echo json_encode(['error' => 'Error en conexión a la BBDD']);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            echo json_encode($db->getById($_GET['id']));
        } elseif (isset($_GET['cart_id'])) {
            echo json_encode($db->getByCartId($_GET['cart_id']));
        } else {
            echo json_encode($db->getAll());
        }
        break;

    case 'POST':
        try {
            $data = getData();
            $response = $db->insert($data['cart_id'], $data['product_id'], $data['cantidad']);
            echo json_encode($response);
        } catch (Exception $e) {
            header('HTTP/1.1 400 Bad Request');
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;

    case 'PUT':
        try {
            $data = getData();
            $response = $db->update($data['id'], $data['cart_id'], $data['product_id'], $data['cantidad']);
            echo json_encode($response);
        } catch (Exception $e) {
            header('HTTP/1.1 400 Bad Request');
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;

    case 'DELETE':
    $data = getData();
    $deleted = $db->delete($data['id']);
    if ($deleted) {
        echo json_encode(['success' => true]);
    } else {
        header('HTTP/1.1 404 Not Found');
        echo json_encode(['error' => 'ID no encontrado']);
    }
    break;


    default:
        header('HTTP/1.1 405 Method Not Allowed');
        header('Allow: GET, POST, PUT, DELETE');
        break;
}
