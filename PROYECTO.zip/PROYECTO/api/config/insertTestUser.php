<?php
// insertTestUser.php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require __DIR__ . '/../db/DbUsers.php';

try {
    $db = new DbUsers();
} catch (Exception $e) {
    die("Error al conectar con la base de datos: " . $e->getMessage());
}

// Datos del usuario de prueba
$nombre = "sesion";
$email = "sesion@gmail.com";
$password = "1234";   // contraseña en claro
$rol = "admin";

try {
    // 🔹 Insertar usuario SIN hacer hash aquí
    // DbUsers->insert() se encarga de hashear la contraseña
    $user = $db->insert($nombre, $email, $password, $rol);

    echo "Usuario creado correctamente:\n";
    echo "ID: " . $user['id'] . "\n";
    echo "Nombre: " . $user['nombre'] . "\n";
    echo "Email: " . $user['email'] . "\n";
    echo "Rol: " . $user['rol'] . "\n";

} catch (Exception $e) {
    echo "Error al crear usuario: " . $e->getMessage();
}
