<?php
// config.php
return [
    'db_host' => 'localhost',
    'db_user' => 'admin',
    'db_pass' => 'admin',
    'db_name' => 'restaurante_durums'
];

?>
