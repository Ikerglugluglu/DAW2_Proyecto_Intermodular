<?php
// testLogin.php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
header('Content-Type: application/json');

require __DIR__ . '/session.php';   // tu session.php
require __DIR__ . '/../db/DbUsers.php';

try {
    $db = new DbUsers();
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Error de base de datos: ' . $e->getMessage()]);
    exit;
}

// Simulamos datos de login (puedes cambiar para probar)

$email = $_POST['email'] ?? 'sesion@gmail.com';
$password = $_POST['password'] ?? '1234';

try {
    $user = $db->getByEmail($email);

    if (!password_verify($password, $user['password'])) {
        http_response_code(401);
        echo json_encode(['error' => 'Password incorrecto']);
        exit;
    }

    // Guardamos información en sesión
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['rol'] = $user['rol'];

    // Respondemos con los datos que verá según su rol
    $userId = $_SESSION['user_id'];
    $role = $_SESSION['rol'];

    if ($role === 'cliente') {
        echo json_encode($db->getBasicById($userId));
    } elseif ($role === 'empleado') {
        echo json_encode($db->getAllForEmployee());
    } elseif ($role === 'admin') {
        echo json_encode($db->getAll());
    }

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['error' => $e->getMessage()]);
}
