<?php
// Configuración de la cookie y sesión
session_set_cookie_params([
    "lifetime" => 0,
    "path" => "/",
    "secure" => false, // true en HTTPS
    "httponly" => true,
    "samesite" => "Strict"
]);

session_start();

// 🔹 Funciones helper de sesión

function loginUser($user) {
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_rol'] = $user['rol'];
}

function logoutUser() {
    session_unset();
    session_destroy();
}

function isLogged() {
    if (isset($_SESSION['user_id'])) {
        return true;
    } else {
        return false;
    }
}

function getUserRole() {
    if (isset($_SESSION['user_rol'])) {
        return $_SESSION['user_rol'];
    } else {
        return null;
    }
}

function getUserId() {
    if (isset($_SESSION['user_id'])) {
        return $_SESSION['user_id'];
    } else {
        return null;
    }
}

