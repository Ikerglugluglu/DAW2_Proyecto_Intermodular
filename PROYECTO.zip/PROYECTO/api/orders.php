<?php
header('Content-Type: application/json');
header('Allow: GET, POST, PUT, DELETE');

require 'db/DbOrders.php';

function getData() {
    $contentType = $_SERVER['CONTENT_TYPE'] ?? '';

    if (strpos($contentType, 'application/json') !== false) {
        $data = json_decode(file_get_contents('php://input'), true);
    } elseif (strpos($contentType, 'application/x-www-form-urlencoded') !== false) {
        parse_str(file_get_contents('php://input'), $data);
    } else {
        header('HTTP/1.1 400 Bad Request');
        echo json_encode(['error' => 'Unsupported Content-Type']);
        exit;
    }

    return $data;
}

try {
    $db = new DbOrders();
} catch (Exception $e) {
    header('HTTP/1.1 500 Internal Server Error');
    echo json_encode(['error' => 'Error en conexión a la BBDD']);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        try {
            if (isset($_GET['id'])) {
                echo json_encode($db->getById($_GET['id']));
            } elseif (isset($_GET['user_id'])) {
                echo json_encode($db->getByUserId($_GET['user_id']));
            } else {
                echo json_encode($db->getAll());
            }
        } catch (Exception $e) {
            header('HTTP/1.1 500 Internal Server Error');
            echo json_encode(['error' => 'Error consultando pedidos']);
        }
        break;

    case 'POST':
        try {
            $data = getData();
            $response = $db->insert($data);
            echo json_encode($response);
        } catch (Exception $e) {
            header('HTTP/1.1 400 Bad Request');
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;

    case 'PUT':
    try {
        $data = getData();

        if (!isset($data['id'])) {
            throw new Exception("Falta el id del pedido");
        }

        echo json_encode(
            $db->update($data['id'], $data)
        );
    } catch (Exception $e) {
        header('HTTP/1.1 400 Bad Request');
        echo json_encode(['error' => $e->getMessage()]);
    }
    break;

    case 'DELETE':
        try {
            $data = getData();
            echo json_encode($db->delete($data['id']));
        } catch (Exception $e) {
            header('HTTP/1.1 400 Bad Request');
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;

    default:
        header('HTTP/1.1 405 Method Not Allowed');
        header('Allow: GET, POST, PUT, DELETE');
        break;
}
