<?php
header('Content-Type: application/json');
header('Allow: GET, POST, PUT, DELETE');

require 'db/DbCart.php';

function getData()
{
    $contentType = $_SERVER['CONTENT_TYPE'] ?? '';

    if (strpos($contentType, 'application/json') !== false) {
        $data = json_decode(file_get_contents('php://input'), true);
    } elseif (strpos($contentType, 'application/x-www-form-urlencoded') !== false) {
        parse_str(file_get_contents('php://input'), $data);
    } else {
        http_response_code(400);
        echo json_encode(['error' => 'Unsupported Content-Type']);
        exit;
    }
    return $data;
}

try {
    $db = new DbCart();
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Error en conexión a la BBDD: ' . $e->getMessage()]);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {

    case 'GET':
        try {
            if (isset($_GET['id'])) {
                echo json_encode($db->getById($_GET['id']));
            } elseif (isset($_GET['user_id'])) {
                echo json_encode($db->getByUser($_GET['user_id']));
            } else {
                echo json_encode($db->getAll());
            }
        } catch (Exception $e) {
            http_response_code(404);
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;

    case 'POST':
        try {
            $data = getData();
            $response = $db->insert($data['user_id']);
            http_response_code(201);
            echo json_encode($response);
        } catch (Exception $e) {
            http_response_code(400);
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;

    case 'PUT':
        try {
            $data = getData();
            $response = $db->update($data['id'], $data['user_id']);
            echo json_encode($response);
        } catch (Exception $e) {
            http_response_code(400);
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;

    case 'DELETE':
    $data = getData();
    $deleted = $db->delete($data['id']);
    if ($deleted) {
        echo json_encode(['success' => true]);
    } else {
        header('HTTP/1.1 404 Not Found');
        echo json_encode(['error' => 'ID no encontrado']);
    }
    break;


    default:
        http_response_code(405);
        header('Allow: GET, POST, PUT, DELETE');
        echo json_encode(['error' => 'Método HTTP no permitido']);
        break;
}

