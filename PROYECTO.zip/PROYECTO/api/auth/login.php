<?php
// login.php: autentica usuario y crea sesion
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header("Content-Type: application/json");

require __DIR__ . '/../config/session.php';
require __DIR__ . '/../db/DbUsers.php';

/* 1️⃣ Leer JSON del body */
$rawInput = file_get_contents("php://input");
$data = json_decode($rawInput, true);

if ($data === null) {
    http_response_code(400);
    echo json_encode(["error" => "JSON inválido"]);
    exit;
}

/* 2️⃣ Comprobar datos obligatorios */
if (!isset($data['email']) || !isset($data['password'])) {
    http_response_code(400);
    echo json_encode(["error" => "Email y password son obligatorios"]);
    exit;
}

$email = $data['email'];
$password = $data['password'];

/* 3️⃣ Conectar con la BD */
try {
    $db = new DbUsers();
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(["error" => "Error de conexión a BD"]);
    exit;
}

/* 4️⃣ Buscar usuario */
try {
    $user = $db->getByEmail($email);

    if ($user === null) {
        http_response_code(401);
        echo json_encode(["error" => "Usuario no encontrado"]);
        exit;
    }

    if (isset($user['activo']) && !$user['activo']) {
        http_response_code(403);
        echo json_encode(["error" => "Usuario desactivado"]);
        exit;
    }

    /* 5️⃣ Verificar contraseña */
    if (!password_verify($password, $user['password'])) {
        http_response_code(401);
        echo json_encode(["error" => "Password incorrecto"]);
        exit;
    }

    /* 6️⃣ Crear sesión */
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_name'] = $user['nombre'];
    $_SESSION['user_email'] = $user['email'];
    $_SESSION['user_rol'] = $user['rol'];

    /* 7️⃣ Responder según rol */
    if ($user['rol'] === 'cliente') {
        echo json_encode($db->getBasicById($user['id']));
        exit;
    }

    if ($user['rol'] === 'empleado') {
        echo json_encode($db->getAllForEmployee());
        exit;
    }

    if ($user['rol'] === 'admin') {
        echo json_encode($db->getAll());
        exit;
    }

    /* Rol desconocido */
    http_response_code(403);
    echo json_encode(["error" => "Rol no autorizado"]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(["error" => $e->getMessage()]);
}
