<?php
// checkEmpleado.php: valida rol admin o empleado
require_once "../config/session.php";

$rol = $_SESSION["user_rol"] ?? null;

if (!in_array($rol, ["admin", "empleado"])) {
    http_response_code(403);
    exit;
}
