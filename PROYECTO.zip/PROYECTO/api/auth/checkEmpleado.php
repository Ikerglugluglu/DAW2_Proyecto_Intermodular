<?php
require_once "../session.php";

$rol = $_SESSION["user"]["rol"] ?? null;

if (!in_array($rol, ["admin", "empleado"])) {
    http_response_code(403);
    exit;
}
