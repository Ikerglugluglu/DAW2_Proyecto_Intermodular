<?php
require_once "../session.php";

if (
    !isset($_SESSION["user"]) ||
    $_SESSION["user"]["rol"] !== "admin"
) {
    http_response_code(403);
    exit;
}
