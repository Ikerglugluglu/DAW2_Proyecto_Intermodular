<?php
// checkAdmin.php: valida rol admin
require_once "../config/session.php";

if (!isset($_SESSION["user_rol"]) || $_SESSION["user_rol"] !== "admin") {
    http_response_code(403);
    exit;
}
