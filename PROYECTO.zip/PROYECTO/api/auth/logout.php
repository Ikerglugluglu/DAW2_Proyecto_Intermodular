<?php
// logout.php: destruye sesion
require_once "../config/session.php";

session_unset();
session_destroy();

echo json_encode(["success" => true]);
