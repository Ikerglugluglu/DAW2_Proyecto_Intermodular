<?php
require_once "../session.php";
require_once "../db.php";

$data = json_decode(file_get_contents("php://input"), true);

$nombre = trim($data["nombre"] ?? "");
$email = trim($data["email"] ?? "");
$password = $data["password"] ?? "";

if ($nombre === "" || $email === "" || $password === "") {
    http_response_code(400);
    echo json_encode(["error" => "Datos inválidos"]);
    exit;
}

$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

// 🔐 FORZADO
$rol = "cliente";
$activo = 1;

$sql = "
    INSERT INTO users (nombre, email, password, rol, activo)
    VALUES (?, ?, ?, ?, ?)
";

$stmt = $pdo->prepare($sql);
$stmt->execute([$nombre, $email, $hashedPassword, $rol, $activo]);

echo json_encode(["success" => true]);
