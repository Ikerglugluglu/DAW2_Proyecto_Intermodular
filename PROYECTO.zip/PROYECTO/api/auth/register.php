<?php
// register.php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require_once "../config/session.php";
require_once '../db/DbUsers.php'; // Aquí ya se crea $pdo

header("Content-Type: application/json");

try {
    // 🔹 Conectar con la BD
    $db = new DbUsers();

    // 🔹 Leer JSON del body
    $data = json_decode(file_get_contents("php://input"), true);
    if (!$data) throw new Exception("JSON inválido");

    $nombre = trim($data["nombre"] ?? "");
    $email = trim($data["email"] ?? "");
    $password = $data["password"] ?? "";

    if ($nombre === "" || $email === "" || $password === "") {
        throw new Exception("Todos los campos son obligatorios");
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        throw new Exception("Email inválido");
    }
    $emailLower = strtolower($email);
    if (!(str_ends_with($emailLower, "@gmail.com") || str_ends_with($emailLower, "@hotmail.es"))) {
        throw new Exception("El email debe ser @gmail.com o @hotmail.es");
    }

    // 🔹 Valores forzados
    $rol = "cliente";
    $user = $db->insert($nombre, $email, $password, $rol);

    echo json_encode([
        "success" => true,
        "id" => $user["id"],
        "nombre" => $user["nombre"],
        "email" => $user["email"],
        "rol" => $user["rol"]
    ]);

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "error" => $e->getMessage()
    ]);
}
