<?php
// me.php: devuelve datos de la sesion actual
require_once "../config/session.php";

if (!isset($_SESSION["user_id"])) {
    http_response_code(401);
    echo json_encode(["logged" => false]);
    exit;
}

echo json_encode([
    "logged" => true,
    "user" => [
        "id" => $_SESSION["user_id"],
        "nombre" => $_SESSION["user_name"] ?? null,
        "email" => $_SESSION["user_email"] ?? null,
        "rol" => $_SESSION["user_rol"] ?? null
    ]
]);
