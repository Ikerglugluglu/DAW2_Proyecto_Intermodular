<?php
class DbOrders
{
    private $pdo;

    // Constructor: inicializa la conexión a la BBDD
    public function __construct()
    {
        $config = include __DIR__ . '/../config/config.php';

        try {
            $this->pdo = new PDO(
                "mysql:host={$config['db_host']};dbname={$config['db_name']};charset=utf8mb4",
                $config['db_user'],
                $config['db_pass']
            );
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (Exception $e) {
            throw new Exception("Error al conectar con la base de datos");
        }
    }

    // 🔹 Retorna todos los pedidos
    public function getAll()
    {
        $stmt = $this->pdo->query('SELECT * FROM orders');
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // 🔹 Retorna un pedido por ID
    public function getById($id)
    {
        $stmt = $this->pdo->prepare('SELECT * FROM orders WHERE id = :id');
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // 🔹 Retorna pedidos por usuario
    public function getByUserId($userId)
    {
        $stmt = $this->pdo->prepare('SELECT * FROM orders WHERE user_id = :user_id');
        $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // 🔹 Inserta un nuevo pedido con validación
    public function insert($data)
    {
        // Validar user_id
        $stmt = $this->pdo->prepare('SELECT id FROM users WHERE id = :id');
        $stmt->bindParam(':id', $data['user_id'], PDO::PARAM_INT);
        $stmt->execute();
        if (!$stmt->fetch()) {
            throw new Exception("El user_id {$data['user_id']} no existe");
        }

        // Validar mesa_id si existe
        if (!empty($data['mesa_id'])) {
            $stmt = $this->pdo->prepare('SELECT id FROM restaurant_tables WHERE id = :id');
            $stmt->bindParam(':id', $data['mesa_id'], PDO::PARAM_INT);
            $stmt->execute();
            if (!$stmt->fetch()) {
                throw new Exception("El mesa_id {$data['mesa_id']} no existe");
            }
        }

        // Validar direccion_id si existe
        if (!empty($data['direccion_id'])) {
            $stmt = $this->pdo->prepare('SELECT id FROM addresses WHERE id = :id');
            $stmt->bindParam(':id', $data['direccion_id'], PDO::PARAM_INT);
            $stmt->execute();
            if (!$stmt->fetch()) {
                throw new Exception("El direccion_id {$data['direccion_id']} no existe");
            }
        }

        // Validar enums
        $tipos = ['domicilio','llevar','local'];
        $estados = ['pendiente','preparacion','listo','entregado'];
        $metodos = ['tarjeta','efectivo','online'];

        if (!in_array($data['tipo_pedido'], $tipos)) {
            throw new Exception("Tipo de pedido inválido");
        }
        if (!empty($data['estado']) && !in_array($data['estado'], $estados)) {
            throw new Exception("Estado inválido");
        }
        if (!empty($data['metodo_pago']) && !in_array($data['metodo_pago'], $metodos)) {
            throw new Exception("Método de pago inválido");
        }

        // Preparar insert
        $stmt = $this->pdo->prepare('
            INSERT INTO orders 
            (user_id, tipo_pedido, estado, total, metodo_pago, mesa_id, direccion_id) 
            VALUES (:user_id, :tipo_pedido, :estado, :total, :metodo_pago, :mesa_id, :direccion_id)
        ');

        $estado = $data['estado'] ?? 'pendiente';
        $total = $data['total'] ?? 0.00;
        $mesa_id = $data['mesa_id'] ?? null;
        $direccion_id = $data['direccion_id'] ?? null;
        $metodo_pago = $data['metodo_pago'] ?? 'efectivo';

        $stmt->bindParam(':user_id', $data['user_id'], PDO::PARAM_INT);
        $stmt->bindParam(':tipo_pedido', $data['tipo_pedido'], PDO::PARAM_STR);
        $stmt->bindParam(':estado', $estado, PDO::PARAM_STR);
        $stmt->bindParam(':total', $total);
        $stmt->bindParam(':metodo_pago', $metodo_pago, PDO::PARAM_STR);
        $stmt->bindParam(':mesa_id', $mesa_id, PDO::PARAM_INT);
        $stmt->bindParam(':direccion_id', $direccion_id, PDO::PARAM_INT);

        $stmt->execute();

        return $this->getById($this->pdo->lastInsertId());
    }

    // 🔹 Actualiza un pedido
    private function orderExists($id)
{
    $stmt = $this->pdo->prepare('SELECT id FROM orders WHERE id = :id');
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    return (bool) $stmt->fetch();
}

    public function update($id, $data)
{
    // 1Comprobar que el pedido existe
    if (!$this->orderExists($id)) {
        throw new Exception("El pedido con id $id no existe");
    }

    // Validar mesa_id si viene
    if (!empty($data['mesa_id'])) {
        $stmt = $this->pdo->prepare('SELECT id FROM restaurant_tables WHERE id = :id');
        $stmt->bindParam(':id', $data['mesa_id'], PDO::PARAM_INT);
        $stmt->execute();
        if (!$stmt->fetch()) {
            throw new Exception("El mesa_id {$data['mesa_id']} no existe");
        }
    }

    // Validar direccion_id si viene
    if (!empty($data['direccion_id'])) {
        $stmt = $this->pdo->prepare('SELECT id FROM addresses WHERE id = :id');
        $stmt->bindParam(':id', $data['direccion_id'], PDO::PARAM_INT);
        $stmt->execute();
        if (!$stmt->fetch()) {
            throw new Exception("El direccion_id {$data['direccion_id']} no existe");
        }
    }

    // Validar enums
    $estados = ['pendiente','preparacion','listo','entregado'];
    $metodos = ['tarjeta','efectivo','online'];

    if (!in_array($data['estado'], $estados)) {
        throw new Exception("Estado inválido");
    }

    if (!in_array($data['metodo_pago'], $metodos)) {
        throw new Exception("Método de pago inválido");
    }

    // Update
    $stmt = $this->pdo->prepare(
        'UPDATE orders SET 
            estado = :estado,
            total = :total,
            metodo_pago = :metodo_pago,
            mesa_id = :mesa_id,
            direccion_id = :direccion_id
         WHERE id = :id'
    );

    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->bindParam(':estado', $data['estado'], PDO::PARAM_STR);
    $stmt->bindParam(':total', $data['total']);
    $stmt->bindParam(':metodo_pago', $data['metodo_pago'], PDO::PARAM_STR);
    $stmt->bindParam(':mesa_id', $data['mesa_id'], PDO::PARAM_INT);
    $stmt->bindParam(':direccion_id', $data['direccion_id'], PDO::PARAM_INT);

    $stmt->execute();

    return $this->getById($id);
}


    // 🔹 Elimina un pedido
   public function delete($id)
{
    // 1️⃣ Comprobar que existe
    if (!$this->orderExists($id)) {
        throw new Exception("El pedido con id $id no existe");
    }

    // 2️⃣ Eliminar
    $stmt = $this->pdo->prepare('DELETE FROM orders WHERE id = :id');
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();

    return [
        'message' => "Pedido $id eliminado correctamente"
    ];
}

}
