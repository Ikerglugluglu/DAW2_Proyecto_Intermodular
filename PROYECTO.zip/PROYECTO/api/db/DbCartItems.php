<?php
class DbCartItems
{
    private $pdo;

    // Constructor: inicializa la conexión a la BBDD
    public function __construct()
    {
        $config = include __DIR__ . '/../config/config.php';

        try {
            $this->pdo = new PDO(
                "mysql:host={$config['db_host']};dbname={$config['db_name']};charset=utf8mb4",
                $config['db_user'],
                $config['db_pass']
            );
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (Exception $e) {
            throw new Exception("Error al conectar con la base de datos");
        }
    }

    // 🔹 Retorna todos los items del carrito
    public function getAll()
    {
        $stmt = $this->pdo->query('SELECT * FROM cart_items');
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // 🔹 Retorna un item por ID
    public function getById($id)
    {
        $stmt = $this->pdo->prepare('SELECT * FROM cart_items WHERE id = :id');
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // 🔹 Retorna todos los items de un carrito específico
    public function getByCartId($cart_id)
    {
        $stmt = $this->pdo->prepare('SELECT * FROM cart_items WHERE cart_id = :cart_id');
        $stmt->bindParam(':cart_id', $cart_id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // 🔹 Inserta un nuevo item en el carrito
    public function insert($cart_id, $product_id, $cantidad)
    {
        // Validar que el carrito exista
        $checkCart = $this->pdo->prepare('SELECT id FROM cart WHERE id = :id');
        $checkCart->bindParam(':id', $cart_id, PDO::PARAM_INT);
        $checkCart->execute();
        if (!$checkCart->fetch()) {
            throw new Exception("El cart_id $cart_id no existe");
        }

        // Validar que el producto exista
        $checkProduct = $this->pdo->prepare('SELECT id FROM products WHERE id = :id');
        $checkProduct->bindParam(':id', $product_id, PDO::PARAM_INT);
        $checkProduct->execute();
        if (!$checkProduct->fetch()) {
            throw new Exception("El product_id $product_id no existe");
        }

        // Insertar el item
        $stmt = $this->pdo->prepare(
            'INSERT INTO cart_items (cart_id, product_id, cantidad) 
             VALUES (:cart_id, :product_id, :cantidad)'
        );
        $stmt->bindParam(':cart_id', $cart_id, PDO::PARAM_INT);
        $stmt->bindParam(':product_id', $product_id, PDO::PARAM_INT);
        $stmt->bindParam(':cantidad', $cantidad, PDO::PARAM_INT);
        $stmt->execute();

        return $this->getById($this->pdo->lastInsertId());
    }

    // 🔹 Actualiza un item del carrito
    public function update($id, $cart_id, $product_id, $cantidad)
    {
        // Validar cart_id y product_id
        $checkCart = $this->pdo->prepare('SELECT id FROM cart WHERE id = :id');
        $checkCart->bindParam(':id', $cart_id, PDO::PARAM_INT);
        $checkCart->execute();
        if (!$checkCart->fetch()) {
            throw new Exception("El cart_id $cart_id no existe");
        }

        $checkProduct = $this->pdo->prepare('SELECT id FROM products WHERE id = :id');
        $checkProduct->bindParam(':id', $product_id, PDO::PARAM_INT);
        $checkProduct->execute();
        if (!$checkProduct->fetch()) {
            throw new Exception("El product_id $product_id no existe");
        }

        $stmt = $this->pdo->prepare(
            'UPDATE cart_items
             SET cart_id = :cart_id, product_id = :product_id, cantidad = :cantidad
             WHERE id = :id'
        );
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->bindParam(':cart_id', $cart_id, PDO::PARAM_INT);
        $stmt->bindParam(':product_id', $product_id, PDO::PARAM_INT);
        $stmt->bindParam(':cantidad', $cantidad, PDO::PARAM_INT);
        $stmt->execute();

        return $this->getById($id);
    }

    // 🔹 Elimina un item del carrito
    public function delete($id)
{
    $stmt = $this->pdo->prepare('DELETE FROM cart_items WHERE id = :id');
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();

    return $stmt->rowCount() > 0;
}

}
