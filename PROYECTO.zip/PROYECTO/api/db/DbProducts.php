<?php
class DbProducts
{
    private $pdo;

    public function __construct()
    {
        $config = include __DIR__ . '/../config/config.php';

        try {
            $this->pdo = new PDO(
                "mysql:host={$config['db_host']};dbname={$config['db_name']};charset=utf8mb4",
                $config['db_user'],
                $config['db_pass']
            );
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (Exception $e) {
            throw new Exception("Error al conectar con la base de datos");
        }
    }

    // 🔹 Retorna todos los productos
    public function getAll()
    {
        $stmt = $this->pdo->query('SELECT * FROM products');
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // 🔹 Retorna un producto por ID
    public function getById($id)
    {
        $stmt = $this->pdo->prepare('SELECT * FROM products WHERE id = :id');
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // 🔹 Retorna productos por categoría
    public function getByCategory($categoryId)
    {
        $stmt = $this->pdo->prepare('SELECT * FROM products WHERE category_id = :category_id');
        $stmt->bindParam(':category_id', $categoryId, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // 🔹 Inserta un producto
    public function insert($categoryId, $nombre, $descripcion, $precio, $imagen, $activo)
    {
        // Verificar que la categoría exista si category_id no es NULL
        if ($categoryId !== null) {
            $checkCat = $this->pdo->prepare('SELECT id FROM categories WHERE id = :id');
            $checkCat->bindParam(':id', $categoryId, PDO::PARAM_INT);
            $checkCat->execute();

            if (!$checkCat->fetch()) {
                throw new Exception("El category_id $categoryId no existe");
            }
        }

        $stmt = $this->pdo->prepare(
            'INSERT INTO products (category_id, nombre, descripcion, precio, imagen, activo)
             VALUES (:category_id, :nombre, :descripcion, :precio, :imagen, :activo)'
        );

        $stmt->bindParam(':category_id', $categoryId, PDO::PARAM_INT);
        $stmt->bindParam(':nombre', $nombre, PDO::PARAM_STR);
        $stmt->bindParam(':descripcion', $descripcion, PDO::PARAM_STR);
        $stmt->bindParam(':precio', $precio);
        $stmt->bindParam(':imagen', $imagen, PDO::PARAM_STR);
        $stmt->bindParam(':activo', $activo, PDO::PARAM_INT);

        $stmt->execute();

        return $this->getById($this->pdo->lastInsertId());
    }

    // 🔹 Actualiza un producto
    public function update($id, $categoryId, $nombre, $descripcion, $precio, $imagen, $activo)
    {
        // Verificar que la categoría exista si category_id no es NULL
        if ($categoryId !== null) {
            $checkCat = $this->pdo->prepare('SELECT id FROM categories WHERE id = :id');
            $checkCat->bindParam(':id', $categoryId, PDO::PARAM_INT);
            $checkCat->execute();

            if (!$checkCat->fetch()) {
                throw new Exception("El category_id $categoryId no existe");
            }
        }

        $stmt = $this->pdo->prepare(
            'UPDATE products
             SET category_id = :category_id,
                 nombre = :nombre,
                 descripcion = :descripcion,
                 precio = :precio,
                 imagen = :imagen,
                 activo = :activo
             WHERE id = :id'
        );

        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->bindParam(':category_id', $categoryId, PDO::PARAM_INT);
        $stmt->bindParam(':nombre', $nombre, PDO::PARAM_STR);
        $stmt->bindParam(':descripcion', $descripcion, PDO::PARAM_STR);
        $stmt->bindParam(':precio', $precio);
        $stmt->bindParam(':imagen', $imagen, PDO::PARAM_STR);
        $stmt->bindParam(':activo', $activo, PDO::PARAM_INT);

        $stmt->execute();

        return $this->getById($id);
    }

    // 🔹 Elimina un producto por ID
public function delete($id)
{
    try {
        $stmt = $this->pdo->prepare('DELETE FROM products WHERE id = :id');
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            return true;
        } else {
            return false;
        }
    } catch (PDOException $e) {
        // Comprobar si es un error de FK
        if ($e->getCode() === '23000') {
            throw new Exception("No se puede eliminar el producto: existen registros en cart_items que lo usan.");
        } else {
            throw $e; // Otros errores PDO
        }
    }
}


}
