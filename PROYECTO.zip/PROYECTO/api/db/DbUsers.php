<?php

class DbUsers
{
    private $pdo;

    public function __construct()
    {
        $config = include __DIR__ . '/../config/config.php';

        try {
            $this->pdo = new PDO(
                "mysql:host={$config['db_host']};dbname={$config['db_name']};charset=utf8mb4",
                $config['db_user'],
                $config['db_pass']
            );
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (Exception $e) {
            throw new Exception('Error al conectar con la base de datos');
        }
    }

    /* ===================== GET ===================== */

    public function getAll()
    {
        $stmt = $this->pdo->query('SELECT * FROM users');
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getById($id)
    {
        $stmt = $this->pdo->prepare('SELECT * FROM users WHERE id = :id');
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();

        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$user) {
            throw new Exception("No existe el usuario con id $id");
        }

        return $user;
    }

    /* ===================== INSERT ===================== */

    public function insert($nombre, $email, $password, $rol)
    {
        // 🔴 verificar que no exista el email
        $stmtCheck = $this->pdo->prepare('SELECT id FROM users WHERE email = :email');
        $stmtCheck->bindParam(':email', $email);
        $stmtCheck->execute();

        if ($stmtCheck->fetch()) {
            throw new Exception("El email $email ya está registrado");
        }

        $stmt = $this->pdo->prepare(
            'INSERT INTO users (nombre, email, password, rol) 
             VALUES (:nombre, :email, :password, :rol)'
        );

        // 🔴 Hashear la contraseña antes de guardar
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        $stmt->bindParam(':nombre', $nombre);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':password', $hashedPassword);
        $stmt->bindParam(':rol', $rol);

        $stmt->execute();

        return $this->getById($this->pdo->lastInsertId());
    }

    /* ===================== UPDATE ===================== */

    public function update($id, $nombre, $email, $rol, $activo)
    {
        // 🔴 comprobar que existe
        $this->getById($id);

        // 🔴 si se actualiza email, verificar que no exista en otro usuario
        $stmtCheck = $this->pdo->prepare('SELECT id FROM users WHERE email = :email AND id != :id');
        $stmtCheck->bindParam(':email', $email);
        $stmtCheck->bindParam(':id', $id, PDO::PARAM_INT);
        $stmtCheck->execute();

        if ($stmtCheck->fetch()) {
            throw new Exception("El email $email ya está registrado en otro usuario");
        }

        $stmt = $this->pdo->prepare(
            'UPDATE users
             SET nombre = :nombre,
                 email = :email,
                 rol = :rol,
                 activo = :activo
             WHERE id = :id'
        );

        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->bindParam(':nombre', $nombre);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':rol', $rol);
        $stmt->bindParam(':activo', $activo, PDO::PARAM_INT);

        $stmt->execute();

        return $this->getById($id);
    }

    /* ===================== "DELETE" ===================== */

    public function delete($id)
    {
        // 🔴 comprobar que existe
        $this->getById($id);

        // 🔴 desactivar en vez de borrar
        $stmt = $this->pdo->prepare(
            'UPDATE users SET activo = 0 WHERE id = :id'
        );
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();

        return ['mensaje' => "Usuario $id desactivado correctamente"];
    }
}
