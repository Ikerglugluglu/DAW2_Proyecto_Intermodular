<?php
class DbCart
{
    private $pdo;

    public function __construct()
    {
        $config = include __DIR__ . '/../config/config.php';

        try {
            $this->pdo = new PDO(
                "mysql:host={$config['db_host']};dbname={$config['db_name']};charset=utf8mb4",
                $config['db_user'],
                $config['db_pass']
            );
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (Exception $e) {
            throw new Exception("Error al conectar con la base de datos: " . $e->getMessage());
        }
    }

    // Retorna todos los carritos
    public function getAll()
    {
        $stmt = $this->pdo->query('SELECT * FROM cart');
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Retorna carrito por ID
    public function getById($id)
    {
        $stmt = $this->pdo->prepare('SELECT * FROM cart WHERE id = :id');
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        $cart = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$cart) {
            throw new Exception("Carrito con id $id no encontrado");
        }
        return $cart;
    }

    // Retorna carritos por user_id
    public function getByUser($user_id)
    {
        $stmt = $this->pdo->prepare('SELECT * FROM cart WHERE user_id = :user_id');
        $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Inserta un nuevo carrito
    public function insert($user_id)
    {
        // Verificar que el usuario exista
        $checkUser = $this->pdo->prepare('SELECT id FROM users WHERE id = :id');
        $checkUser->bindParam(':id', $user_id, PDO::PARAM_INT);
        $checkUser->execute();
        if (!$checkUser->fetch()) {
            throw new Exception("El user_id $user_id no existe");
        }

        $insertCart = $this->pdo->prepare('INSERT INTO cart (user_id) VALUES (:user_id)');
        $insertCart->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $insertCart->execute();

        return $this->getById($this->pdo->lastInsertId());
    }

    // Actualiza el user_id de un carrito
    public function update($id, $user_id)
    {
        // Verificar que el carrito exista
        $this->getById($id);

        // Verificar que el user_id exista
        $checkUser = $this->pdo->prepare('SELECT id FROM users WHERE id = :id');
        $checkUser->bindParam(':id', $user_id, PDO::PARAM_INT);
        $checkUser->execute();
        if (!$checkUser->fetch()) {
            throw new Exception("El user_id $user_id no existe");
        }

        $stmt = $this->pdo->prepare('UPDATE cart SET user_id = :user_id WHERE id = :id');
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $stmt->execute();

        return $this->getById($id);
    }

    // Elimina un carrito por id
    // 🔹 Elimina un carrito por id
public function delete($id)
{
    $stmt = $this->pdo->prepare('DELETE FROM cart WHERE id = :id');
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        return true;
    } else {
        return false;
    }
}

}
