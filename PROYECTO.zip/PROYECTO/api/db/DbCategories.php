<?php
class DbCategories
{
    private $pdo;

    public function __construct()
    {
        // Cargamos la configuración
        $config = include __DIR__ . '/../config/config.php';

        try {
            $this->pdo = new PDO(
                "mysql:host={$config['db_host']};dbname={$config['db_name']};charset=utf8mb4",
                $config['db_user'],
                $config['db_pass']
            );
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (Exception $e) {
            throw new Exception("Error al conectar con la base de datos");
        }
    }

    // Retorna todas las categorías
    public function getAll()
    {
        $stmt = $this->pdo->query('SELECT * FROM categories');
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Retorna una categoría por ID
    public function getById($id)
    {
        $stmt = $this->pdo->prepare('SELECT * FROM categories WHERE id = :id');
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Inserta una nueva categoría
    public function insert($nombre, $descripcion)
    {
        $stmt = $this->pdo->prepare(
            'INSERT INTO categories (nombre, descripcion) VALUES (:nombre, :descripcion)'
        );
        $stmt->bindParam(':nombre', $nombre, PDO::PARAM_STR);
        $stmt->bindParam(':descripcion', $descripcion, PDO::PARAM_STR);
        $stmt->execute();

        return $this->getById($this->pdo->lastInsertId());
    }

    // Actualiza una categoría
    public function update($id, $nombre, $descripcion)
    {
        $stmt = $this->pdo->prepare(
            'UPDATE categories SET nombre = :nombre, descripcion = :descripcion WHERE id = :id'
        );
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->bindParam(':nombre', $nombre, PDO::PARAM_STR);
        $stmt->bindParam(':descripcion', $descripcion, PDO::PARAM_STR);
        $stmt->execute();

        return $this->getById($id);
    }

    // Elimina una categoría (soft delete no necesario, normalmente sí)
    public function delete($id)
    {
        $stmt = $this->pdo->prepare('DELETE FROM categories WHERE id = :id');
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);

        try {
            $stmt->execute();
            return ['deleted_id' => $id];
        } catch (PDOException $e) {
            // Si falla por FK, devolvemos error controlado
            throw new Exception("No se puede eliminar la categoría: ".$e->getMessage());
        }
    }
}
