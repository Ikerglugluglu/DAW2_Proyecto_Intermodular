<?php

class DbReservations
{
    private $pdo;

    public function __construct()
    {
        $config = include __DIR__ . '/../config/config.php';

        try {
            $this->pdo = new PDO(
                "mysql:host={$config['db_host']};dbname={$config['db_name']};charset=utf8mb4",
                $config['db_user'],
                $config['db_pass']
            );
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (Exception $e) {
            throw new Exception('Error al conectar con la base de datos');
        }
    }

    /* ===================== GET ===================== */

    public function getAll()
    {
        $stmt = $this->pdo->query('SELECT * FROM reservations');
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getById($id)
    {
        $stmt = $this->pdo->prepare(
            'SELECT * FROM reservations WHERE id = :id'
        );
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();

        $reservation = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$reservation) {
            throw new Exception("No existe la reserva con id $id");
        }

        return $reservation;
    }

    /* ===================== INSERT ===================== */

    public function insert($userId, $tableId, $fecha, $hora, $personas, $estado = 'activa')
    {
        // 🔴 comprobar user_id
        $checkUser = $this->pdo->prepare(
            'SELECT id FROM users WHERE id = :id'
        );
        $checkUser->bindParam(':id', $userId, PDO::PARAM_INT);
        $checkUser->execute();

        if (!$checkUser->fetch()) {
            throw new Exception("El user_id $userId no existe");
        }

        // 🔴 comprobar table_id
        $checkTable = $this->pdo->prepare(
            'SELECT id FROM restaurant_tables WHERE id = :id'
        );
        $checkTable->bindParam(':id', $tableId, PDO::PARAM_INT);
        $checkTable->execute();

        if (!$checkTable->fetch()) {
            throw new Exception("El table_id $tableId no existe");
        }

        // 🔴 insertar
        $stmt = $this->pdo->prepare(
            'INSERT INTO reservations
             (user_id, table_id, fecha, hora, personas, estado)
             VALUES
             (:user_id, :table_id, :fecha, :hora, :personas, :estado)'
        );

        $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
        $stmt->bindParam(':table_id', $tableId, PDO::PARAM_INT);
        $stmt->bindParam(':fecha', $fecha);
        $stmt->bindParam(':hora', $hora);
        $stmt->bindParam(':personas', $personas, PDO::PARAM_INT);
        $stmt->bindParam(':estado', $estado);
/*
        // 1️⃣ Comprobar solapamiento
    $check = $this->pdo->prepare(
        'SELECT id FROM reservations
        WHERE table_id = :table_id
        AND fecha = :fecha
        AND estado = "activa"
        AND hora BETWEEN SUBTIME(:hora, "01:00:00") AND ADDTIME(:hora, "01:00:00")'
    );
    $check->execute([
        ':table_id' => $tableId,
        ':fecha' => $fecha,
        ':hora' => $hora
    ]);
    if ($check->fetch()) {
        throw new Exception('La mesa ya está ocupada en ese horario');
    }
*/
        $stmt->execute();

        return $this->getById($this->pdo->lastInsertId());
    }

    /* ===================== UPDATE ===================== */

    public function update($id, $tableId, $fecha, $hora, $personas, $estado)
    {
        // 🔴 comprobar que existe
        $this->getById($id);

        // 🔴 comprobar table_id
        $checkTable = $this->pdo->prepare(
            'SELECT id FROM restaurant_tables WHERE id = :id'
        );
        $checkTable->bindParam(':id', $tableId, PDO::PARAM_INT);
        $checkTable->execute();

        if (!$checkTable->fetch()) {
            throw new Exception("El table_id $tableId no existe");
        }

        $stmt = $this->pdo->prepare(
            'UPDATE reservations
             SET table_id = :table_id,
                 fecha = :fecha,
                 hora = :hora,
                 personas = :personas,
                 estado = :estado
             WHERE id = :id'
        );

        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->bindParam(':table_id', $tableId, PDO::PARAM_INT);
        $stmt->bindParam(':fecha', $fecha);
        $stmt->bindParam(':hora', $hora);
        $stmt->bindParam(':personas', $personas, PDO::PARAM_INT);
        $stmt->bindParam(':estado', $estado);
/*
        // 1️⃣ Comprobar solapamiento
    $check = $this->pdo->prepare(
        'SELECT id FROM reservations
        WHERE table_id = :table_id
        AND fecha = :fecha
        AND estado = "activa"
        AND hora BETWEEN SUBTIME(:hora, "01:00:00") AND ADDTIME(:hora, "01:00:00")'
    );
    $check->execute([
        ':table_id' => $tableId,
        ':fecha' => $fecha,
        ':hora' => $hora
    ]);
    if ($check->fetch()) {
        throw new Exception('La mesa ya está ocupada en ese horario');
    }
*/
        $stmt->execute();

        if ($stmt->rowCount() === 0) {
            throw new Exception("No se ha modificado ningún campo de la reserva $id");
        }

        return $this->getById($id);
    }

    /* ===================== DELETE ===================== */

    public function delete($id)
    {
        // 🔴 comprobar que existe
        $this->getById($id);

        $stmt = $this->pdo->prepare(
            'DELETE FROM reservations WHERE id = :id'
        );
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();

        if ($stmt->rowCount() === 0) {
            throw new Exception("No se ha podido borrar la reserva $id");
        }

        return ['mensaje' => "Reserva $id eliminada correctamente"];
    }
}
