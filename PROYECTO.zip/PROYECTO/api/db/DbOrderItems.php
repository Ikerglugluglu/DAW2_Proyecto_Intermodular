<?php

class DbOrderItems
{
    private $pdo;

    public function __construct()
    {
        $config = include __DIR__ . '/../config/config.php';

        try {
            $this->pdo = new PDO(
                "mysql:host={$config['db_host']};dbname={$config['db_name']};charset=utf8mb4",
                $config['db_user'],
                $config['db_pass']
            );
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (Exception $e) {
            throw new Exception('Error al conectar con la base de datos');
        }
    }

    /* ===================== GET ===================== */

    public function getAll()
    {
        $stmt = $this->pdo->query('SELECT * FROM order_items');
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getById($id)
    {
        $stmt = $this->pdo->prepare(
            'SELECT * FROM order_items WHERE id = :id'
        );
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();

        $item = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$item) {
            throw new Exception("No existe el order_item con id $id");
        }

        return $item;
    }

    public function getByOrderId($orderId)
    {
        $stmt = $this->pdo->prepare(
            'SELECT * FROM order_items WHERE order_id = :order_id'
        );
        $stmt->bindParam(':order_id', $orderId, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /* ===================== INSERT ===================== */

    public function insert($orderId, $productId, $cantidad, $precioUnitario)
    {
        // 🔴 validar order_id
        $checkOrder = $this->pdo->prepare(
            'SELECT id FROM orders WHERE id = :id'
        );
        $checkOrder->bindParam(':id', $orderId, PDO::PARAM_INT);
        $checkOrder->execute();

        if (!$checkOrder->fetch()) {
            throw new Exception("El order_id $orderId no existe");
        }

        // 🔴 validar product_id
        $checkProduct = $this->pdo->prepare(
            'SELECT id FROM products WHERE id = :id'
        );
        $checkProduct->bindParam(':id', $productId, PDO::PARAM_INT);
        $checkProduct->execute();

        if (!$checkProduct->fetch()) {
            throw new Exception("El product_id $productId no existe");
        }

        // 🔴 insertar
        $stmt = $this->pdo->prepare(
            'INSERT INTO order_items (order_id, product_id, cantidad, precio_unitario)
             VALUES (:order_id, :product_id, :cantidad, :precio)'
        );

        $stmt->bindParam(':order_id', $orderId, PDO::PARAM_INT);
        $stmt->bindParam(':product_id', $productId, PDO::PARAM_INT);
        $stmt->bindParam(':cantidad', $cantidad, PDO::PARAM_INT);
        $stmt->bindParam(':precio', $precioUnitario);

        $stmt->execute();

        return $this->getById($this->pdo->lastInsertId());
    }

    /* ===================== UPDATE ===================== */

    public function update($id, $cantidad, $precioUnitario)
    {
        // 🔴 comprobar que existe
        $this->getById($id);

        $stmt = $this->pdo->prepare(
            'UPDATE order_items
             SET cantidad = :cantidad,
                 precio_unitario = :precio
             WHERE id = :id'
        );

        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->bindParam(':cantidad', $cantidad, PDO::PARAM_INT);
        $stmt->bindParam(':precio', $precioUnitario);

        $stmt->execute();

        if ($stmt->rowCount() === 0) {
            throw new Exception("No se ha modificado ningún campo del order_item $id");
        }

        return $this->getById($id);
    }

    /* ===================== DELETE ===================== */

    public function delete($id)
    {
        // 🔴 comprobar que existe
        $this->getById($id);

        $stmt = $this->pdo->prepare(
            'DELETE FROM order_items WHERE id = :id'
        );
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();

        if ($stmt->rowCount() === 0) {
            throw new Exception("No se ha podido borrar el order_item $id");
        }

        return ['mensaje' => "order_item $id eliminado correctamente"];
    }
}

