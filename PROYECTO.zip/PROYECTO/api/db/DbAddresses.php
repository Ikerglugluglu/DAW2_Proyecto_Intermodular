<?php

class DbAddresses
{
    private $pdo; // Conexión PDO a la base de datos

    public function __construct()
    {
        $config = include __DIR__ . '/../config/config.php';

        try {
            $this->pdo = new PDO(
                "mysql:host={$config['db_host']};dbname={$config['db_name']};charset=utf8mb4",
                $config['db_user'],
                $config['db_pass']
            );
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (Exception $e) {
            throw new Exception("Error al conectar con la base de datos");
        }
    }

    public function getAll()
    {
        $stmt = $this->pdo->query('SELECT * FROM addresses');
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getByUserId($userId)
    {
        $stmt = $this->pdo->prepare('SELECT * FROM addresses WHERE user_id = :user_id');
        $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getById($id)
    {
        $stmt = $this->pdo->prepare('SELECT * FROM addresses WHERE id = :id');
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$result) {
            throw new Exception("Dirección con ID $id no encontrada");
        }
        return $result;
    }

    public function insert($userId, $direccion, $ciudad, $cp, $telefono)
    {
        // Verificar que el usuario exista
        $checkUser = $this->pdo->prepare('SELECT id FROM users WHERE id = :id');
        $checkUser->bindParam(':id', $userId, PDO::PARAM_INT);
        $checkUser->execute();

        if (!$checkUser->fetch()) {
            throw new Exception("El user_id $userId no existe");
        }

        $stmt = $this->pdo->prepare(
            'INSERT INTO addresses (user_id, direccion, ciudad, cp, telefono)
             VALUES (:user_id, :direccion, :ciudad, :cp, :telefono)'
        );

        $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
        $stmt->bindParam(':direccion', $direccion, PDO::PARAM_STR);
        $stmt->bindParam(':ciudad', $ciudad, PDO::PARAM_STR);
        $stmt->bindParam(':cp', $cp, PDO::PARAM_STR);
        $stmt->bindParam(':telefono', $telefono, PDO::PARAM_STR);
        $stmt->execute();

        return $this->getById($this->pdo->lastInsertId());
    }

    public function update($id, $userId, $direccion, $ciudad, $cp, $telefono)
    {
        // Verificar que la dirección exista
        $this->getById($id);

        // Verificar que el usuario exista
        $checkUser = $this->pdo->prepare('SELECT id FROM users WHERE id = :id');
        $checkUser->bindParam(':id', $userId, PDO::PARAM_INT);
        $checkUser->execute();
        if (!$checkUser->fetch()) {
            throw new Exception("El user_id $userId no existe");
        }

        $stmt = $this->pdo->prepare(
            'UPDATE addresses
             SET user_id = :user_id,
                 direccion = :direccion,
                 ciudad = :ciudad,
                 cp = :cp,
                 telefono = :telefono
             WHERE id = :id'
        );

        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
        $stmt->bindParam(':direccion', $direccion, PDO::PARAM_STR);
        $stmt->bindParam(':ciudad', $ciudad, PDO::PARAM_STR);
        $stmt->bindParam(':cp', $cp, PDO::PARAM_STR);
        $stmt->bindParam(':telefono', $telefono, PDO::PARAM_STR);

        $stmt->execute();
        return $this->getById($id);
    }

    // 🔹 Elimina una dirección por ID
public function delete($id)
{
    $stmt = $this->pdo->prepare('DELETE FROM addresses WHERE id = :id');
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();

    // Comprobamos cuántas filas fueron afectadas
    if ($stmt->rowCount() > 0) {
        return true; // Se eliminó algo
    } else {
        return false; // No se encontró el id
    }
}

}

