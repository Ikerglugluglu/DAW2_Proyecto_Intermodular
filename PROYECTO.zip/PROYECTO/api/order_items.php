<?php

header('Content-Type: application/json');
header('Allow: GET, POST, PUT, DELETE');

require 'db/DbOrderItems.php';

function getData()
{
    $contentType = $_SERVER['CONTENT_TYPE'] ?? '';

    if (strpos($contentType, 'application/json') !== false) {
        return json_decode(file_get_contents('php://input'), true);
    }

    if (strpos($contentType, 'application/x-www-form-urlencoded') !== false) {
        parse_str(file_get_contents('php://input'), $data);
        return $data;
    }

    header('HTTP/1.1 400 Bad Request');
    echo json_encode(['error' => 'Unsupported Content-Type']);
    exit;
}

try {
    $db = new DbOrderItems();
} catch (Exception $e) {
    header('HTTP/1.1 500 Internal Server Error');
    echo json_encode(['error' => $e->getMessage()]);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];

try {

    switch ($method) {

        case 'GET':
            if (isset($_GET['id'])) {
                echo json_encode($db->getById($_GET['id']));
            } elseif (isset($_GET['order_id'])) {
                echo json_encode($db->getByOrderId($_GET['order_id']));
            } else {
                echo json_encode($db->getAll());
            }
            break;

        case 'POST':
            $data = getData();

            if (
                !isset($data['order_id'], $data['product_id'], $data['cantidad'], $data['precio_unitario'])
            ) {
                throw new Exception('Faltan campos obligatorios');
            }

            echo json_encode(
                $db->insert(
                    $data['order_id'],
                    $data['product_id'],
                    $data['cantidad'],
                    $data['precio_unitario']
                )
            );
            break;

        case 'PUT':
            $data = getData();

            if (!isset($data['id'], $data['cantidad'], $data['precio_unitario'])) {
                throw new Exception('Faltan campos obligatorios');
            }

            echo json_encode(
                $db->update(
                    $data['id'],
                    $data['cantidad'],
                    $data['precio_unitario']
                )
            );
            break;

        case 'DELETE':
            $data = getData();

            if (!isset($data['id'])) {
                throw new Exception('El id es obligatorio');
            }

            echo json_encode($db->delete($data['id']));
            break;

        default:
            header('HTTP/1.1 405 Method Not Allowed');
            header('Allow: GET, POST, PUT, DELETE');
    }

} catch (Exception $e) {
    header('HTTP/1.1 400 Bad Request');
    echo json_encode(['error' => $e->getMessage()]);
}
