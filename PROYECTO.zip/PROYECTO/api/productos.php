<?php
header('Content-Type: application/json');
header('Allow: GET, POST, PUT, DELETE');

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require 'db/DbProducts.php';

function getData() {
    $contentType = $_SERVER['CONTENT_TYPE'] ?? '';

    if (strpos($contentType, 'application/json') !== false) {
        $data = json_decode(file_get_contents('php://input'), true);
    } elseif (strpos($contentType, 'application/x-www-form-urlencoded') !== false) {
        parse_str(file_get_contents('php://input'), $data);
    } else {
        header('HTTP/1.1 400 Bad Request');
        echo json_encode(['error' => 'Unsupported Content-Type']);
        exit;
    }

    return $data;
}

try {
    $db = new DbProducts();
} catch (Exception $e) {
    header('HTTP/1.1 500 Internal Server Error');
    echo json_encode(['error' => 'Error en conexión a la BBDD']);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        try {
            if (isset($_GET['id'])) {
                echo json_encode($db->getById($_GET['id']));
            } elseif (isset($_GET['category_id'])) {
                echo json_encode($db->getByCategory($_GET['category_id']));
            } else {
                echo json_encode($db->getAll());
            }
        } catch (Exception $e) {
            header('HTTP/1.1 500 Internal Server Error');
            echo json_encode(['error' => 'Error consultando productos']);
        }
        break;

    case 'POST':
        try {
            $data = getData();
            $response = $db->insert(
                $data['category_id'] ?? null,
                $data['nombre'],
                $data['descripcion'] ?? null,
                $data['precio'],
                $data['imagen'] ?? null,
                $data['activo'] ?? 1
            );
            echo json_encode($response);
        } catch (Exception $e) {
            header('HTTP/1.1 400 Bad Request');
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;

    case 'PUT':
        try {
            $data = getData();
            $response = $db->update(
                $data['id'],
                $data['category_id'] ?? null,
                $data['nombre'],
                $data['descripcion'] ?? null,
                $data['precio'],
                $data['imagen'] ?? null,
                $data['activo'] ?? 1
            );
            echo json_encode($response);
        } catch (Exception $e) {
            header('HTTP/1.1 400 Bad Request');
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;

   case 'DELETE':
    $data = getData();
    try {
        $deleted = $db->delete($data['id']);
        if ($deleted) {
            echo json_encode(['success' => true]);
        } else {
            header('HTTP/1.1 404 Not Found');
            echo json_encode(['error' => 'ID no encontrado']);
        }
    } catch (Exception $e) {
        header('HTTP/1.1 400 Bad Request');
        echo json_encode(['error' => $e->getMessage()]);
    }
    break;



    default:
        header('HTTP/1.1 405 Method Not Allowed');
        header('Allow: GET, POST, PUT, DELETE');
        break;
}
