<?php
header('Content-Type: application/json');
header('Allow: GET, POST, PUT, DELETE');

require __DIR__ . '/config/session.php'; // <<< Aquí tu sesión
require __DIR__ . '/db/DbUsers.php';

// 🔹 Función para obtener datos JSON de la request
function getData() {
    $contentType = $_SERVER['CONTENT_TYPE'] ?? '';

    if (strpos($contentType, 'application/json') !== false) {
        return json_decode(file_get_contents('php://input'), true);
    }

    if (strpos($contentType, 'application/x-www-form-urlencoded') !== false) {
        parse_str(file_get_contents('php://input'), $data);
        return $data;
    }

    header('HTTP/1.1 400 Bad Request');
    echo json_encode(['error' => 'Unsupported Content-Type']);
    exit;
}

// 🔹 Requerimos login para cualquier operación
if (!isLogged()) {
    header('HTTP/1.1 401 Unauthorized');
    echo json_encode(['error' => 'No estás logueado']);
    exit;
}

$role = getUserRole();
$userId = getUserId();

try {
    $db = new DbUsers();
} catch (Exception $e) {
    header('HTTP/1.1 500 Internal Server Error');
    echo json_encode(['error' => $e->getMessage()]);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];

try {
    switch ($method) {
        case 'GET':
            if ($role === 'cliente') {
                // Cliente solo ve su propia info
                echo json_encode($db->getBasicById($userId));
            } elseif ($role === 'empleado') {
                // Empleado ve todos pero campos limitados
                echo json_encode($db->getAllForEmployee());
            } elseif ($role === 'admin') {
                // Admin ve todo
                echo json_encode($db->getAll());
            } else {
                throw new Exception("Rol no permitido");
            }
            break;

        case 'POST':
            if ($role !== 'admin') {
                throw new Exception("Solo admin puede crear usuarios");
            }
            $data = getData();
            if (!isset($data['nombre'], $data['email'], $data['password'])) {
                throw new Exception('Faltan campos obligatorios');
            }
            // Rol siempre explícito, si no viene se asigna 'cliente'
            $rol = isset($data['rol']) && in_array($data['rol'], ['cliente','empleado','admin']) ? $data['rol'] : 'cliente';
            echo json_encode(
                $db->insert(
                    $data['nombre'],
                    $data['email'],
                    $data['password'],
                    $rol
                )
            );
            break;

        case 'PUT':
            $data = getData();
            if (!isset($data['id'], $data['nombre'], $data['email'])) {
                throw new Exception('Faltan campos obligatorios');
            }

            if ($role === 'cliente') {
                // Solo puede actualizarse a sí mismo
                if ($data['id'] != $userId) {
                    throw new Exception("No puedes modificar otro usuario");
                }
                echo json_encode($db->updateClient($data['id'], $data['nombre'], $data['email'], $data['password'] ?? null));
            } elseif ($role === 'empleado') {
                // Puede actualizar solo nombre/email de cualquier usuario
                echo json_encode($db->updateEmployee($data['id'], $data['nombre'], $data['email']));
            } elseif ($role === 'admin') {
                // Admin actualiza todo
                if (!isset($data['rol'], $data['activo'])) {
                    throw new Exception('Faltan campos obligatorios para admin');
                }
                echo json_encode($db->update($data['id'], $data['nombre'], $data['email'], $data['rol'], $data['activo']));
            } else {
                throw new Exception("Rol no permitido");
            }
            break;

        case 'DELETE':
            if ($role !== 'admin') {
                throw new Exception("Solo admin puede desactivar usuarios");
            }
            $data = getData();
            if (!isset($data['id'])) {
                throw new Exception('El id es obligatorio');
            }
            echo json_encode($db->delete($data['id']));
            break;

        default:
            header('HTTP/1.1 405 Method Not Allowed');
            header('Allow: GET, POST, PUT, DELETE');
    }

} catch (Exception $e) {
    header('HTTP/1.1 400 Bad Request');
    echo json_encode(['error' => $e->getMessage()]);
}

