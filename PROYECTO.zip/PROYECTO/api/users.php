<?php
// users.php: CRUD de usuarios con permisos por rol
header('Content-Type: application/json');
header('Allow: GET, POST, PUT, DELETE');

require __DIR__ . '/config/session.php'; // <<< Aquí tu sesión
require __DIR__ . '/db/DbUsers.php';

// Validar email permitido
function isAllowedEmail($email) {
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return false;
    }
    $emailLower = strtolower($email);
    if (str_ends_with($emailLower, "@gmail.com")) {
        return true;
    }
    if (str_ends_with($emailLower, "@hotmail.es")) {
        return true;
    }
    return false;
}

// 🔹 Función para obtener datos JSON de la request
function getData() {
    $contentType = $_SERVER['CONTENT_TYPE'] ?? '';

    if (strpos($contentType, 'application/json') !== false) {
        return json_decode(file_get_contents('php://input'), true);
    }

    if (strpos($contentType, 'application/x-www-form-urlencoded') !== false) {
        parse_str(file_get_contents('php://input'), $data);
        return $data;
    }

    header('HTTP/1.1 400 Bad Request');
    echo json_encode(['error' => 'Unsupported Content-Type']);
    exit;
}

// 🔹 Requerimos login para cualquier operación
if (!isLogged()) {
    header('HTTP/1.1 401 Unauthorized');
    echo json_encode(['error' => 'No estás logueado']);
    exit;
}

$role = getUserRole();
$userId = getUserId();

try {
    $db = new DbUsers();
} catch (Exception $e) {
    header('HTTP/1.1 500 Internal Server Error');
    echo json_encode(['error' => $e->getMessage()]);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];

try {
    switch ($method) {
        case 'GET':
            if (isset($_GET['name']) && $_GET['name'] !== '') {
                if ($role === 'cliente') {
                    throw new Exception("No tienes permisos para buscar usuarios");
                }

                $users = $db->getByName($_GET['name']);

                if ($role === 'empleado') {
                    $users = array_filter($users, function ($u) {
                        return isset($u['activo']) && $u['activo'] == 1;
                    });
                    $users = array_map(function ($u) {
                        return [
                            'id' => $u['id'],
                            'nombre' => $u['nombre'],
                            'email' => $u['email'],
                            'creado_en' => $u['creado_en']
                        ];
                    }, $users);
                }

                echo json_encode($users);
                break;
            }

            if ($role === 'cliente') {
                // Cliente solo ve su propia info
                echo json_encode($db->getBasicById($userId));
            } elseif ($role === 'empleado') {
                // Empleado ve solo usuarios activos con campos limitados
                echo json_encode($db->getAllActiveForEmployee());
            } elseif ($role === 'admin') {
                // Admin ve todo
                echo json_encode($db->getAll());
            } else {
                throw new Exception("Rol no permitido");
            }
            break;

        case 'POST':
            if ($role !== 'admin') {
                throw new Exception("Solo admin puede crear usuarios");
            }
            $data = getData();
            if (!isset($data['nombre'], $data['email'], $data['password'])) {
                throw new Exception('Faltan campos obligatorios');
            }
            if ($data['nombre'] === '' || $data['email'] === '' || $data['password'] === '') {
                throw new Exception('Faltan campos obligatorios');
            }
            if (!isAllowedEmail($data['email'])) {
                throw new Exception('El email debe ser @gmail.com o @hotmail.es');
            }
            // Rol siempre explícito, si no viene se asigna 'cliente'
            $rol = isset($data['rol']) && in_array($data['rol'], ['cliente','empleado','admin']) ? $data['rol'] : 'cliente';
            echo json_encode(
                $db->insert(
                    $data['nombre'],
                    $data['email'],
                    $data['password'],
                    $rol
                )
            );
            break;

        case 'PUT':
            $data = getData();
            if (!isset($data['id'], $data['nombre'], $data['email'])) {
                throw new Exception('Faltan campos obligatorios');
            }
            if ($data['nombre'] === '' || $data['email'] === '') {
                throw new Exception('Faltan campos obligatorios');
            }
            if (!isAllowedEmail($data['email'])) {
                throw new Exception('El email debe ser @gmail.com o @hotmail.es');
            }

            // Si es el propio usuario y no se envian rol/activo, permitir update basico
            if ($data['id'] == $userId && !isset($data['rol']) && !isset($data['activo'])) {
                if (isset($data['password']) && $data['password'] === '') {
                    throw new Exception('La contraseña es obligatoria');
                }
                $updated = $db->updateClient($data['id'], $data['nombre'], $data['email'], $data['password'] ?? null);
                $_SESSION['user_name'] = $updated['nombre'];
                $_SESSION['user_email'] = $updated['email'];
                echo json_encode($updated);
                break;
            }

            if ($role === 'cliente') {
                // Solo puede actualizarse a sí mismo
                if ($data['id'] != $userId) {
                    throw new Exception("No puedes modificar otro usuario");
                }
                if (isset($data['password']) && $data['password'] === '') {
                    throw new Exception('La contraseña es obligatoria');
                }
                $updated = $db->updateClient($data['id'], $data['nombre'], $data['email'], $data['password'] ?? null);
                if ($data['id'] == $userId) {
                    $_SESSION['user_name'] = $updated['nombre'];
                    $_SESSION['user_email'] = $updated['email'];
                }
                echo json_encode($updated);
            } elseif ($role === 'empleado') {
                // Puede actualizar solo nombre/email de cualquier usuario
                if (isset($data['password']) && $data['password'] === '') {
                    throw new Exception('La contraseña es obligatoria');
                }
                $updated = $db->updateEmployee($data['id'], $data['nombre'], $data['email']);
                if ($data['id'] == $userId) {
                    $_SESSION['user_name'] = $data['nombre'];
                    $_SESSION['user_email'] = $data['email'];
                }
                echo json_encode($updated);
            } elseif ($role === 'admin') {
                // Admin actualiza todo
                if (!isset($data['rol'], $data['activo'])) {
                    throw new Exception('Faltan campos obligatorios para admin');
                }
                if (isset($data['password']) && $data['password'] === '') {
                    throw new Exception('La contraseña es obligatoria');
                }
                $updated = $db->update(
                    $data['id'],
                    $data['nombre'],
                    $data['email'],
                    $data['rol'],
                    $data['activo'],
                    $data['password'] ?? null
                );
                if ($data['id'] == $userId) {
                    $_SESSION['user_name'] = $updated['nombre'];
                    $_SESSION['user_email'] = $updated['email'];
                    $_SESSION['user_rol'] = $updated['rol'];
                }
                echo json_encode($updated);
            } else {
                throw new Exception("Rol no permitido");
            }
            break;

        case 'DELETE':
            if ($role !== 'admin') {
                throw new Exception("Solo admin puede desactivar usuarios");
            }
            $data = getData();
            if (!isset($data['id'])) {
                throw new Exception('El id es obligatorio');
            }
            echo json_encode($db->delete($data['id']));
            break;

        default:
            header('HTTP/1.1 405 Method Not Allowed');
            header('Allow: GET, POST, PUT, DELETE');
    }

} catch (Exception $e) {
    header('HTTP/1.1 400 Bad Request');
    echo json_encode(['error' => $e->getMessage()]);
}
