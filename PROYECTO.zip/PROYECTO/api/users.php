<?php
header('Content-Type: application/json');
header('Allow: GET, POST, PUT, DELETE');

require __DIR__ . '/db/DbUsers.php';

function getData() {
    $contentType = $_SERVER['CONTENT_TYPE'] ?? '';

    if (strpos($contentType, 'application/json') !== false) {
        return json_decode(file_get_contents('php://input'), true);
    }

    if (strpos($contentType, 'application/x-www-form-urlencoded') !== false) {
        parse_str(file_get_contents('php://input'), $data);
        return $data;
    }

    header('HTTP/1.1 400 Bad Request');
    echo json_encode(['error' => 'Unsupported Content-Type']);
    exit;
}

try {
    $db = new DbUsers();
} catch (Exception $e) {
    header('HTTP/1.1 500 Internal Server Error');
    echo json_encode(['error' => $e->getMessage()]);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];

try {
    switch ($method) {
        case 'GET':
            if (isset($_GET['id'])) {
                echo json_encode($db->getById($_GET['id']));
            } else {
                echo json_encode($db->getAll());
            }
            break;

        case 'POST':
            $data = getData();
            if (!isset($data['nombre'], $data['email'], $data['password'], $data['rol'])) {
                throw new Exception('Faltan campos obligatorios');
            }
            echo json_encode(
                $db->insert(
                    $data['nombre'],
                    $data['email'],
                    $data['password'],
                    $data['rol']
                )
            );
            break;

        case 'PUT':
            $data = getData();
            if (!isset($data['id'], $data['nombre'], $data['email'], $data['rol'], $data['activo'])) {
                throw new Exception('Faltan campos obligatorios');
            }
            echo json_encode(
                $db->update(
                    $data['id'],
                    $data['nombre'],
                    $data['email'],
                    $data['rol'],
                    $data['activo']
                )
            );
            break;

        case 'DELETE':
            $data = getData();
            if (!isset($data['id'])) {
                throw new Exception('El id es obligatorio');
            }
            echo json_encode($db->delete($data['id']));
            break;

        default:
            header('HTTP/1.1 405 Method Not Allowed');
            header('Allow: GET, POST, PUT, DELETE');
    }

} catch (Exception $e) {
    header('HTTP/1.1 400 Bad Request');
    echo json_encode(['error' => $e->getMessage()]);
}

